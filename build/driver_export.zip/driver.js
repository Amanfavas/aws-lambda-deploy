const result = require('./result');
const driverModel = require('./model').driverModel;
const helper = require('./util');
const constant = require('./constant')();
const isIt = constant.isIt;
const role = constant.ROLE;
const mongoose = require('mongoose');

module.exports = {
  getDrivers: (event, cb, principals) => {
    const data = helper.getQueryData(event);
    console.log(data);
    if (!data) {
      result.invalidInput(cb);
    }
    const query = formQuery(principals, data);
    console.log('call paginate');
    driverModel.find(query).populate({ path: 'assignTeam' }).exec(function (err, drivers) {
      console.log(err, JSON.stringify(drivers));
      if (err) {
        result.sendServerError(cb);
      } else {
        result.sendSuccess(cb, drivers);
      }
    });
  }
};


function formQuery(principals, qryData) {
  const defaultQuery = {isDeleted: isIt.NO, role: role.DRIVER}; //add all default values here
  const query = defaultQuery;
  if (qryData.filter && qryData.filter.search) {
    //TODO This should be optimised with common search & fields structure. ex: fields:['teamName','description']
    query.name = {$regex: `.*${qryData.filter.search}.*`, '$options': 'i'};
  }

  if (qryData.filter && qryData.filter.state) {
    //TODO This should be optimised with common search & fields structure. ex: fields:['teamName','description']
    query.driverStatus = qryData.filter.state;
  }

  //add auth query
  if (helper.isAdmin(principals)) {
    query['clientId'] = principals['sub'];
  } else {
    //manager
    query['clientId'] = principals['clientId'];
    var teams = principals['teams'];
    teams = teams.map((team) => {
      return mongoose.Types.ObjectId(team);
    });
    query['assignTeam'] = {'$in': teams};
  }
  console.log(query);
  return query;
}
