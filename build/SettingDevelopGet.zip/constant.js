module.exports = {
  "DB": {
    "URL": "mongodb://vignesh:Vignesh123@deliforce-shard-00-00-6geto.mongodb.net:27017," +
    "deliforce-shard-00-01-6geto.mongodb.net:27017," +
    "deliforce-shard-00-02-6geto.mongodb.net:27017/deliforce?replicaSet=deliforce-shard-0&authSource=admin&ssl=true",
    "POOL_SIZE": 2
  },
  "STATUS": {
    "DUPLICATE_TEAM_NAME": 208,
    "MISSING_MANDATORY": 209,
    "INVALID_DATATYPE": 210,
    "MISSING_FIELD_OR_TYPE": 211
  }
}
//{"fromTrigger":1}
