const result = require('./result');
const teamModel = require('./model');
const helper = require('./util');

module.exports = {
  checkDuplicate:(event, cb, principals) => {
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
    const data = helper.getBodyData(event);
    if(!data){
      result.invalidInput(cb);
    }
    teamModel.findOne({teamName: data.teamName, clientId:clientId}, (err, team) => {
      if (err) {
        result.sendServerError(cb);
      } else if (team) {
        result.duplicateTeamName(cb);
      } else {
        upsertTeam(data,clientId,cb);
      }
    });
  }
};

function generateRandam() {
  return Math.floor(Math.random() * 9000) + 1000;
}
function upsertTeam(data , clientId ,cb) {
  let promise;
  if (data._id) {
    const id = data._id;
    delete data._id;
    // delete data._v;
    promise = teamModel.update({clientId:clientId,_id:id}, {$set:data});
  } else {
    const newTeam = new teamModel(data);
    newTeam.clientId = clientId;
    newTeam.teamId = generateRandam();
    promise = newTeam.save();
  }
  promise.then((data) => {
    result.sendSuccess(cb,data);
  }).catch((error)=>{ console.log(error); handlerError(error,cb)});
}


function handlerError(err ,cb) {
  if (err.teamName) {
    result.invalidTeamName(cb);
  } else {
    result.sendServerError(cb);
  }
}

