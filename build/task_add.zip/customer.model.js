const mongoose = require('mongoose')
const Schema = mongoose.Schema;


const customerSchema = new Schema({

  // customerName:{type:Schema.Types.ObjectId,ref:'customer'},
  clientId:{type:String},
  name: {type: String},
  phone: {type: String},
  email: {type: String},
  address: Schema.Types.Mixed,
  isActive:{type:Number,default:1},
  isDeleted:{type:Number,default:0},
  color:{type :String}

}, {strite: false});

const taskLogSchema=new Schema({
  adminName:{type:String},
  date:{type:Date},
  Taskstatus:{type:String},
  driverName:{type:String},
  text:{type:String},
  TaskId:{type:String},
  created:{type: Date, default: Date.now}
});


const userSchema=new Schema({
  name:{type:String,required:true},
  role:{type:Number,required:true}

});
const customer = mongoose.model('customer', customerSchema);
const TaskLog=mongoose.model('taskLog',taskLogSchema);
const User=mongoose.model('user',userSchema);
module.exports={'CUSTOMER':customer,'TASKLOG':TaskLog,'USER':User};

