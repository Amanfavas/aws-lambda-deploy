const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const constant = require('./constant');
const model = require('./model');
const customerModel = model.customerModel;
const tasklogModel = model.tasklogModel;
const taskM = model.task;
const settingModel = model.settingModel;
const userModel = model.userModel;


module.exports = {


  //princial  manager- clientId , role , sub , teams
  //admin - sub , role

  saveTask: (event, cb, principals) => {

    const data = helper.getBodyData(event);
    if (!data) {
      result.invalidInput(cb);
    } else {
      const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
      let userData;
      let taskData;
      checkDriver(data, clientId)
        .then((user) => {
          console.log('user++', JSON.stringify(user));
          userData = user;
          return createTask(data, clientId, cb);
        })
        .then((task) => {
          taskData = task;
          console.log('task++', JSON.stringify(task));
          const promises = [
            createCustomer(data, clientId),
            createTasklog(taskData, userData, clientId, principals.role)
          ];
          return Promise.all(promises);
        })
        .then(() => {
          result.sendSuccess(cb, taskData);
        })
        .catch((err) => {
          console.log('err++++ ', JSON.stringify(err));
          result.sendServerError(cb)
        });
    }
  }
};


function checkDriver(data, clientId) {
  return new Promise((resolve, reject) => {
    if (data.driver) {
      const driverObjId = mongoose.Types.ObjectId(data.driver);
      userModel.find({$or: [{_id: driverObjId}, {'cognitoSub': clientId}]})
        .then((response) => {
          const result = {adminName: '', driverName: ''};
          response.find((driver) => {
            driver = driver.toObject();
            if (driver._id.toString() === data.driver) {
              result.driverName = (driver.clientId === clientId) ? driver.name : '';
            }
            if (driver.cognitoSub === clientId) {
              result.adminName = driver.name;
            }
          });

          // check driverid is secured one
          if (result.driverName) resolve(result);
          else reject({message: 'invalid driver'});

        }).catch((err) => reject(err));
    } else {
      userModel.findOne({'cognitoSub': clientId})
        .then((response) => {
          const data = response.toObject();
          resolve({adminName: data.name, driverName: ''});
        }).catch((err) => reject(err));

    }
  });


}


function createTask(data, clientId, cb) {
  const taskModel = model.task.getTaskModel(data['businessType']);
  if (!taskModel) {
    return Promise.reject('model not found for businessType');
  }
  data.clientId = clientId;
  data.taskStatus = (data.driver) ? constant.TASK_STATUS.ASSIGNED : constant.TASK_STATUS.UNASSIGNED;
  //TODO fetch from setting table
  data.settings = {};
  return new taskModel(data).save();

}

function createTasklog(data, ud, clientId, role) {
  const models = [];
  const taskLogStatus = constant.TASK_LOG_STATUS;
  const model = {
    user: ud.adminName,
    taskStatus: taskLogStatus.CREATED,
    taskId: data._id,
    clientId: clientId,
    role: role
  };

  models.push(model);
  if(ud.driverName){
    const model = {
      user: ud.adminName,
      taskStatus: taskLogStatus.ASSIGNED,
      taskId: data._id,
      driverName:ud.driverName,
      clientId: clientId,
      role: role
    };
   models.push(model);
  }


  return tasklogModel.insertMany(models);
}

function createCustomer(data, clientId) {
  const customer = {};
  customer.clientId = clientId;
  customer.name = data.name;
  customer.email = data.email;
  customer.phone = data.phone;
  customer.address = data.address;
  const newCustomer = new customerModel(customer);
  return newCustomer.save()
}
