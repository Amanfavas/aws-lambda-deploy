const result = require('./result');
const taskModel = require('./model').taskModel;
const helper = require('./util');
const mongoose= require('mongoose');
const constant = require('./constant')();
const role = constant.ROLE;
const isIt = constant.isIt;
const empty = require('is-empty');
const moment = require('moment');


module.exports = {

  getTasks: (event, cb, principals) => {
    const data = helper.getQueryData(event);
    console.log(data);
    if (!data) {
      result.invalidInput(cb);
    }
    const query = formQuery(principals, data);
    //for daystarting Time
    if (!empty(data.filter.dateFilter.length)) {
      const startDate = new Date(data.filter.dateFilter);
      startDate.setSeconds(0);
      startDate.setHours(0);
      startDate.setMinutes(0);
      //for day End Time
      const dateMidnight = new Date(data.filter.dateFilter);
      dateMidnight.setHours(23);
      dateMidnight.setMinutes(59);
      dateMidnight.setSeconds(59);
      let date = {
        $gt: startDate,
        $lt: dateMidnight
      };

      console.log(startDate);
      console.log(dateMidnight);
      //query[0].$match.$and.push({'date': date});

      // var startDate= moment(data.filter.dateFilter[0]).startOf('day')
      // var dateMidnight=moment(data.filter.dateFilter[1]).endOf('day')

      query[0].$match.$and.push({'date': date} );

    }
    if (!empty(data.filter.TeamsFilter)) {
      let assignTeam = mongoose.Types.ObjectId(data.filter.TeamsFilter);
      query.push({$match: {'driverDetails.assignTeam': assignTeam}});

    }
    if (!empty(data._id)) {
      query[0].$match.$and.push({'_id': mongoose.Types.ObjectId(data._id)});
    }
    if(empty(data.businessType)){

      result.businessMissing(cb);
      return;
    }
    console.log(JSON.stringify(query));
    taskModel.aggregate(query, function (error, data) {
      if (error) {
        result.sendServerError(cb);
      } else {
        result.sendSuccess(cb,data);
      }

    });

  }
};


function formQuery(principals, qryData) {




  var defaultQuery = [
    {
      '$match': {
        '$and': [


          {'isDeleted': isIt.NO},
          {'businessType':qryData.businessType}

        ]
      }
    }, {
      $lookup: {
        from: 'users', localField: 'driver', foreignField: '_id',
        as: 'driverDetails'
      }
    }
  ];

  var query = defaultQuery;





  // if (qryData.filter && qryData.filter.search) {
  //   //TODO This should be optimised with common search & fields structure. ex: fields:['teamName','description']
  //   query[0].$match.$and.push({name:{$regex: `.*${qryData.filter.search}.*`}});
  // }

  //add auth query
  if (helper.isAdmin(principals)) {
    console.log(principals.sub);

    query[0].$match.$and.push({'clientId': principals.sub});


  } else {
    //manager
    query[0].$match.$and.push({'clientId': principals['clientId']});
    var teams= principals['teams'];
    if(teams.length){
      teams= teams.map((team)=>{
        return mongoose.Types.ObjectId(team);
      });

      query.push({$match:{'driverDetails.assignTeam': {'$in': teams}}});
    }

  }

  return query;
}



