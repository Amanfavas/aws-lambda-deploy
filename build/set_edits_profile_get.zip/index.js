const uuid = require('uuid');
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();


exports.handler = (event, context, callback) => {
    const clientId = '1234567899'

	

	  var params = {
        TableName: 'Team',
        IndexName: "clientId-index",
        KeyConditionExpression: "#id=:id",
        ExpressionAttributeNames:{
        	"#id" : "clientId"
            },
        ExpressionAttributeValues: {
        	//":id":"e2596c10-0805-11e8-8a2c-c7a27c0de0cd"
        	":id":clientId
            },
        };

		dynamoDb.query(params,function (err, data) {
		if (err) {
			console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
			callback(null, {
				statusCode: err.statusCode || 500,
				headers: {'Content-Type': 'text/plain','Access-Control-Allow-Origin':'*'},
				body: 'Couldn\'t create the product item.',
			});
		} else {
			console.log("GetItem succeeded:", JSON.stringify(data, null, 2));
			const response = {
				headers: {
                'Access-Control-Allow-Origin': '*',
            },
				statusCode: 200,
				body: JSON.stringify(data),
			};
			callback(null, response);
		}
	});
};

  