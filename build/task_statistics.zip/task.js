const result = require('./result');
const taskModel = require('./model').TASK;
const helper = require('./util');
const constant = require('./constant')();
const taskS = constant.TASK_STATUS;
const _ = require('lodash');
const moment = require('moment');
const empty = require('is-empty');
const mongoose = require('mongoose');


module.exports = {

  taskStatistics: (event, cb, principals) => {
    const data = helper.getQueryData(event);

    if (!data) {
      result.invalidInput(cb);
      return;
    }

    const query = formQuery(principals, data);
    const date = new Date();
    date.setDate(date.getDate() - 6);
    var startDate = new Date(date.getFullYear(), date.getMonth() + 0, date.getDate());
    var dateMidnight = new Date();


    startDate = new Date(startDate);
    startDate.setSeconds(0);
    startDate.setHours(0);
    startDate.setMinutes(0);
    //for day End Time
    dateMidnight = new Date(dateMidnight);
    dateMidnight.setHours(23);
    dateMidnight.setMinutes(59);
    dateMidnight.setSeconds(59);


    query.$match.$and.push({date: {"$gte": new Date(startDate), "$lte": new Date(dateMidnight)}});


    if (!empty(data.filter.businessType)) {
      query.$match.$and.push({businessType: data.filter.businessType});

    }

    console.log(query);

    taskModel.aggregate(
      [

        //{'$match':{category:(!empty(body.filter.categoryFilter))? body.filter.categoryFilter :''}},
        {
          $lookup: {
            from: 'users',
            localField: 'driver',
            foreignField: '_id',
            as: 'driverDetails'
          }
        },

        query,

        {
          $project: {
            yearMonthDay: {$dateToString: {format: "%Y-%m-%d", date: "$date"}},
            time: {$dateToString: {format: "%H:%M:%S:%L", date: "$date"}},
            'driver': "$driverDetails",
            'taskStatus': '$taskStatus',
            'category': '$category'
          }
        },


        {
          "$group": {
            "_id": {
              "yearMonthDay": "$yearMonthDay",
              "taskStatus": "$taskStatus"
            },
            "taskStatus": {"$sum": 1}
          }
        },
        {
          "$group": {
            "_id": "$_id.yearMonthDay",
            "taskStatus": {
              "$push": {
                "taskStatus": "$_id.taskStatus",
                "count": "$taskStatus"
              },
            },
            "count": {"$sum": "$taskStatus"}
          }
        },
        {$sort: {"_id": 1}}


      ]
    ).then((data) => {

      var datesArry = getDates(new Date(startDate), new Date(dateMidnight)).map((date) => {
        // console.log(date)l
        return this.newData = date.toISOString().slice(0, 10);
      });

      console.log(JSON.stringify(data))
      let ourObject = [];
      const mock = {
        "taskStatus": [
          {
            "taskStatus": 1,
            "count": 0
          },
          {
            "taskStatus": 2,
            "count": 0
          },
          {
            "taskStatus": 3,
            "count": 0
          },
          {
            "taskStatus": 4,
            "count": 0
          },
          {
            "taskStatus": 5,
            "count": 0
          },
          {
            "taskStatus": 6,
            "count": 0
          },
          {
            "taskStatus": "traveled",
            "count": 0
          },
          {
            "taskStatus": "fuel",
            "count": 0,

          },
          {
            "taskStatus": "carbon",
            "count": 0,

          }

        ],
        count: 0
      };
      datesArry.forEach((v) => {
        ourObject.push(Object.assign({_id: v}, mock));
      });

      var mergedList = _.map(ourObject, function (item) {
        const find = _.find(data, {_id: item._id});
        if (find) {
          const ts = _.unionBy(find.taskStatus, item.taskStatus, "taskStatus");
          return _.extend(item, {taskStatus: ts}, {count: find.count});
        } else {
          return item;
        }
      });
      result.sendSuccess(cb, mergedList)
    })
      .catch((error) => result.sendServerError(cb));
  }


};


function formQuery(principals, qryData) {
  const defaultQuery = {
    '$match': {
      '$and': []
    }
  }
  const query = defaultQuery;
  // if (qryData.filter && qryData.filter.search) {
  //   //TODO This should be optimised with common search & fields structure. ex: fields:['teamName','description']
  //   query.name = {$regex: `.*${qryData.filter.search}.*`};
  // }

  //add auth query
  if (helper.isAdmin(principals)) {
    query.$match.$and.push({'clientId': principals['sub']});

  } else {
    //manager
    query.$match.$and.push({'clientId': principals['clientId']})
    var teams = principals['teams'];
    teams = teams.map((team) => {
      return mongoose.Types.ObjectId(team);
    })
    query.$match.$and.push({'driverDetails.assignTeam': {'$in': teams}});
  }
  console.log(query);
  return query;
}

function getDates(startDate, endDate) {


  let dates = [];
  this.currentDate = startDate;
  let addDays = function (days) {
    let date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
  };
  while (this.currentDate <= endDate) {
    dates.push(this.currentDate);
    this.currentDate = addDays.call(this.currentDate, 1);
  }
  return dates;
// Usage

}
