const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant')();
const tables = constant.TABLES

//action=[{code:1,exist:0/1,mandatory:0/1}]
//autoAllocation:{enable:true/false,method:1/2/3,expire:anyNumber,retry:anyNumber}

const taskSchema = new Schema({});
const driverSchema = new Schema({});
const teamSchema = new Schema({});
const taskModel= mongoose.model(tables.TASK, taskSchema);
const driverModel= mongoose.model(tables.DRIVER, driverSchema);
const teamModel= mongoose.model(tables.TEAM, teamSchema);

module.exports={ 'TASK':taskModel,'DRIVER':driverModel,'TEAM':teamModel};
