const result = require('./result');
const settingModel = require('./model');
const helper = require('./util');
const mongoose = require('mongoose');

module.exports = {
  updateSetting:(event,cb,principals) => {
    const data = helper.getBodyData(event);
    console.log(data);
    if(!data){
      result.invalidInput(cb);
    } else {
      const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
      const id = mongoose.Types.ObjectId(data['_id']);
      delete data['_id'];
      settingModel.update({clientId: clientId, _id: id}, data, {multi: false, runValidators: true}).then((resp) => {
        result.sendSuccess(cb ,resp);
      }).catch((error) => {result.sendServerError(cb)});
    }
  }
};







