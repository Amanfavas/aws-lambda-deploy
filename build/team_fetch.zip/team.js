const result = require('./result');
const teamModel = require('./model');
const helper = require('./util');
const constant = require('./constant')();
const isIt = constant.isIt;


module.exports = {

  getTeams: (event, cb, principals) => {
    const data = helper.getQueryData(event);
    const query = formTeamQuery(principals, data);
    teamModel.paginate(query, {
      page: data.page || 1,
      limit: data.limit || 10,
      sort: {'created_at': -1}
    }, function (err, teams) {
      console.log(err, teams);
      if (err) {
        console.log(err);
        result.sendServerError(cb);
      } else {
        console.log(teams);
        result.sendSuccess(cb, teams);
      }
    });
  }
};


function formTeamQuery(principals, qryData) {
  const defaultQuery = {isDeleted: isIt.NO}; //add all default values here
  const query = defaultQuery;
  if (qryData.filter && qryData.filter.search) {
    //TODO This should be optimised with common search & fields structure. ex: fields:['teamName','description']
    query.teamName = {$regex: `.*${qryData.filter.search}.*`};
  }
  //add auth query
  if (helper.isAdmin(principals)) {
    query['clientId'] = principals['sub'];
  } else {
    //manager
    query['clientId'] = principals['clientId'];
    query['_id'] = {'$in': principals['teams']};
  }
  console.log(query);
  return query;
}
