const result = require('./result');
const constant = require('./constant')();
const teamModel = require('./model').teamModel;
const driverModel = require('./model').driverModel;
const helper = require('./util');
const isIt = constant.isIt;
const mongoose = require('mongoose');


module.exports = {
  checkDriver: (event, cb, principals) => {
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
    if (!clientId) {
      result.sendUnAuth(cb);
    }
    const data = helper.getQueryData(event);
    console.log(data);
    driverModel.findOne({clientId: clientId, assignTeam: mongoose.Types.ObjectId(data._id)})
      .then((driverResult) => {
        if (driverResult) {
          result.teamHasDriver(cb);
          return;
        } else {
          deleteTeam(data, clientId, cb);
        }
      })
      .catch(() => {
        result.sendServerError(cb);
      });
  }
};

function deleteTeam(data, clientId, cb) {
  teamModel.update({_id: data._id, clientId: clientId}, {isDeleted: isIt.YES}, {multi: false}).then((data) => {
    result.sendSuccess(cb, data);
  }).catch(() => {
    result.sendServerError(cb);
  });
}

