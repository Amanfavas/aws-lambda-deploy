const mongoose=require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant')();
const tables = constant.TABLES;

const driverSchema = new Schema({});

const taskSchemea= new Schema({});
const teamSchema=new Schema({});


const driverModel = mongoose.model(tables.DRIVER,driverSchema);
const taskModel = mongoose.model(tables.TASK,taskSchemea);
const teamModel = mongoose.model(tables.TEAM,teamSchema);
module.exports = {driverModel: driverModel, taskModel: taskModel, teamModel: teamModel};

