const result = require('./result');
const driverModel = require('./model').driverModel;
const helper = require('./util');
const constant = require('./constant')();
const mongoose =require('mongoose');
const isIt = constant.isIt;

module.exports = {

  getDrivers: (event, cb, principals) => {
    const query = {isDeleted:isIt.NO, role: constant.ROLE.DRIVER,driverStatus:{$ne:constant.DRIVER_STATUS.BLOCKED}};
    //add auth query
    if (helper.isAdmin(principals)) {
      query['clientId'] = principals['sub'];
    } else {
      //manager
      query['clientId'] = principals['clientId'];

      var teams = principals['teams'];
      teams = teams.map((team) => {
        return mongoose.Types.ObjectId(team);
      });
      query['assignTeam'] = {'$in': teams};
    }
    console.log(query);
    driverModel.find(query, function (err, drivers) {
      console.log(err, JSON.stringify(drivers));
      if (err) {
        result.sendServerError(cb);
      } else {
        result.sendSuccess(cb, drivers);
      }
    });
  }
};

