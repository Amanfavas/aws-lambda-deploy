const result = require('./result');
const settingModel = require('./model');
const helper = require('./util');

module.exports = {
  fetchSetting:(event, cb, principals) => {
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
    console.log(clientId+'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh');
    settingModel.find({clientId: clientId, isCurrent: true}, {
      businessType: 1
    }, function (err, settings) {

      console.log(err, settings);
      if (err) {
        result.sendServerError(err);
      } else {
        result.sendSuccess(cb,settings[0]);
      }
    });
  }
};







