const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const constant = require('./constant')();

//const settingModel = require('./model').setting;
const taskModel = require('./model').task;
const userModel = require('./model').user;


module.exports = {
  init: (event, cb, principals) => {
    const data = helper.getQueryData(event);
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];

    if(!data.businessType){
      result.invalidInput(cb);
      return;
    }

    const baseQuery = formQuery(data, clientId);
    if (principals.role === constant.ROLE.ADMIN) {
      getTasks(baseQuery, data, cb);
    } else {
      formAuthQuery(baseQuery, principals, clientId)
        .then((query) => {
          if (!query.driver) {
            //send empty
            const tasks = {"docs": [], "total": 0, "limit": 10, "page": 1, "pages": 1};
            result.sendSuccess(cb, tasks);
          } else {
            getTasks(query, data, cb);
          }

        })
        .catch((err) => {
          console.log(err);
          result.sendServerError(cb);
        });
    }
  }

};

function getTasks(query, data, cb) {
  const pageNumber = data.page || 1;
  const pageLimit = data.limit || 10;
  console.log('call paginate');

  taskModel.paginate(query, {
    page: pageNumber,
    limit: pageLimit,
    populate:'driver',
    sort: {'created_at': -1}
  }).then((tasks) => {
    console.log(tasks);
    result.sendSuccess(cb, tasks);
  }).catch((err) => result.sendServerError(cb));
}


/*function getCategory(clientId) {
  return settingModel.findOne({isActive: 1, clientId: clientId});
}*/

function formQuery(data, clientId) {
  const query = {clientId: clientId, isDeleted: 0, businessType: data.businessType};
  if (data.filter && data.filter.search) {
    query.name = {$regex: `.*${data.filter.search}.*`, '$options' : 'i'};
    console.log('searching');
  }
  //console.log(empty(body.filter.search));
  if (data.filter && data.filter.dateRange) {
    const startDate = new Date(data.filter.dateRange[0]);
    startDate.setSeconds(0);
    startDate.setHours(0);
    startDate.setMinutes(0);
//for day End Time
    const dateMidnight = new Date(data.filter.dateRange[1]);
    dateMidnight.setHours(23);
    dateMidnight.setMinutes(59);
    dateMidnight.setSeconds(59);
    let date = {
      $gt: startDate,
      $lt: dateMidnight
    };

    console.log('date search ');
    query.date = date;
  }

  if (data.filter && data.filter.driversFilter) {
    query.driver = mongoose.Types.ObjectId(data.filter.driversFilter);
  }

  if (data.filter && data.filter.statusFilter.length) {
    var statusArray = data.filter.statusFilter.map((status)=>{
      return parseInt(status,10);
    });
    query.taskStatus = {$in: statusArray};
  }
  return query;
}


function formAuthQuery(query, principal, clientId) {
  const teams = principal.teams && principal.teams.map((t) => mongoose.Types.ObjectId(t));
  return userModel.find({assignTeam: {$in: teams}, role: constant.ROLE.DRIVER, isDeleted: 0, clientId: clientId})
    .then((drivers) => {
      if (!drivers.length) {
        return query;
      } else {
        const result = [];
        drivers.forEach((d) => {
          result.push(d._id);
        });
        query.driver = {$in: result};
        return query;
      }
    });
}





