const result = require('./result');
const model = require('./model');
const helper = require('./util');


module.exports = {

  multipleChangeStatus: (event, cb, principals) => {
    console.log(event);
    const data = helper.getBodyData(event);
    console.log(data);
    if (!data) {
      console.log('invalid data');
      result.sendServerError(cb);
      return;
    }

    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
    const taskModel = model.task.getTaskModel(data.data['businessType']);

    taskModel.update({_id: {$in: data.data.taskArry},clientId:clientId}, {taskStatus: data.data.status}, {multi: true}).then((data) => {
      console.log(data);
      result.sendSuccess(cb, data);
    }).catch((err)=>{console.log(err);result.sendServerError(cb)});
  }
};







