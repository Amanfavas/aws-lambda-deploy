const result = require('./result');
const preferenceModel = require('./model');
const helper = require('./util');

module.exports = {
  updatePreference:(event, cb, principals)=> {
    const data = helper.getBodyData(event);
    if (!data) {
      result.invalidInput(cb);
    } else {
      const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
      const id = data._id;
      delete data._id;
      data.clientId = clientId;
      preferenceModel.update({clientId: clientId, _id: id},
        data).then((data) => {
        result.sendSuccess(cb,data);
      }).catch((error) => {result.sendServerError(cb)});
    }
  }
};







