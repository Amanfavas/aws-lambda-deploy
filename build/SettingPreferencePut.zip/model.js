var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var preferenceSchema = new Schema({
  clientId: {type: String},
  customizeAgentTextAs: Schema.Types.Mixed,
  customizeManagerTextAs: Schema.Types.Mixed,
  dashboardLanguage: Schema.Types.Mixed,
  customerTrackingLangauge: Schema.Types.Mixed,
  distance: Schema.Types.Mixed,
  timeZone: Schema.Types.Mixed
}, {strite: false});

module.exports = mongoose.model('preference', preferenceSchema);
