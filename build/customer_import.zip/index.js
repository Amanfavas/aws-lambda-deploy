
let cb;
let aws = require('aws-sdk');
let multerS3 = require('multer-s3');
let multer = require('multer');
let express = require('express');

const bodyParser = require('body-parser');
const cors = require('cors');
const compression = require('compression');
const helper =require('./util');


//aws middleware
const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware');
let mongoose = require('mongoose');
let app = express();
const db = require('./db').connect();
const result = require('./result');
const errorCode =require('./error').CODES;

const fs = require('fs');
const csv = require("fast-csv");
const customerModel  = require('./model');


app.use(compression())
app.use(cors())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(awsServerlessExpressMiddleware.eventContext())




aws.config.loadFromPath('./config.json');
aws.config.update({signatureVersion:'v4'});
let s3= new aws.S3({});
let upload=multer({
  storage:multerS3({
    s3:s3,
    bucket:'deliforce-fileupload',
    acl:'public-read',

    metadata:function(req,file,cb){
      cb(null,{fieldName:file.fieldname});
    },
    fileFilter: function (req, file, cb) {
      if (!file.originalname.match(/\.(csv)$/)) {
        return cb(new Error('Only image files are allowed!'));
      }
      cb(null, true);
    },
    key:function(req,file,cb){

        cb(null, Date.now() + file.originalname);
    }


  })
});

function DateChecker(date) {
  return !(new Date(date) == 'Invalid Date');
}
function ValidateEmail(mail)
{
  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
  {
    return (true)
  }

  return (false)
};

function phoneValidation(d) {
  const regex = /^\d+$/;
  const split = d.substring(1).split(' ');
  if (d.charAt(0) !== '+') {
    return false
  } else if (split.length === 2) {
    var arr = split.filter((s) => !regex.test(s));
    return (!arr.length)
  } else {
    return false;
  }
};

// upload.any()
app.post('/customer/import',upload.single('image'),function(req,res,next) {
  console.log(JSON.stringify(req.apiGateway.event));
  const principals = helper.getPrincipals(cb,req.apiGateway.event);
  if (!principals) return;
  const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
  console.log('clientId '+clientId );
  //const clientId='1234';
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");

  console.log(req.file);


  var path = req.file.key;
  aws.config.loadFromPath('./config.json');
  aws.config.update({signatureVersion:'v4'});
  respon=[];

  const s1 = new aws.S3();
  const stream = s1.getObject({ Bucket: 'deliforce-fileupload', Key: path }).createReadStream();

  var parser = csv.fromStream(stream, { headers: true })
    .on("data", function (data) {
      //console.log(data);
      respon.push(data);

    }).on("end", function (data) {
      // console.log(respon);
      //console.log(respon.length);
      var sucessCount=0;
      var failureCount=0;
      var dataArry=[];


      for ( var i=0;i<respon.length;i++ ) {
        console.log(respon[i].customerName);
        console.log(respon[i].phone);
        console.log(respon[i].address);
        console.log(phoneValidation(respon[i].phone));

        if (respon[i].customerName && respon[i].phone && phoneValidation(respon[i].phone) && respon[i].address  && respon[i].email &&ValidateEmail(respon[i].email) )
        {
          //todo actual settings we need to store,clientId
          var query={'name':respon[i].customerName,'phone':respon[i].phone,'clientId':clientId,
            'address':respon[i].address,'email':respon[i].email };

          console.log(query);

          dataArry.push(query);
          sucessCount++;

        }
        else{
          console.log('failuer count');
          failureCount++;
        }
      }
      console.log(sucessCount);
      console.log(failureCount);
      console.log(dataArry);
      if(dataArry.length){


        customerModel.insertMany(dataArry,function(error,data){
          if(error){
            console.log(error);
            res.send('server side errro')
          }
          else{
            res.json({'sucessCount':sucessCount,'failureCount':failureCount});
          }

        })

      }
      else{
        res.send('sucess')
      }


    })

});
db.then(()=>{console.log('data base connectionestablished')

  let server = app.listen(8081, function () {
    let host = server.address().address;
    let port = server.address().port;
    console.log("Example app listening at http://%s:%s", host, port);
  });


})
  .catch((error)=>{process.exit(1)});



module.exports = app;
