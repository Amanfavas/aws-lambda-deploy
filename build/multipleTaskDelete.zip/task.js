const result = require('./result');
const taskModel = require('./model');
const helper = require('./util');
const constant = require('./constant')();
const isIt = constant.isIt;


module.exports = {
  multipleTaskDelete: (event, cb, principals) => {
    // console.log(principals);
    // console.log(event);
    const data = helper.getQueryData(event);
    if(!data) {
      result.invalidInput(cb);
      return;
    }
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
    if(!clientId){
      result.sendUnAuth(cb);
      return;
    }
    taskModel.update({_id: {$in: data.tasks}, clientId:clientId },{isDeleted:isIt.YES }, {multi: true}).then((taskData) => {
      result.sendSuccess(cb , taskData);
    }).catch((err) => result.sendServerError(cb));
  }
};







