const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant')();
const isIt = constant.isIt;
const tables = constant.TABLES;

const taskSchema = new Schema({
  // customerName:{type:Schema.Types.ObjectId,ref:'customer'},
  isDeleted: {type: Number, default: isIt.NO},
}, {strite: false});

module.exports = mongoose.model(tables.TASK, taskSchema);
