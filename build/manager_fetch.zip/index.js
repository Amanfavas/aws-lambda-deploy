let cb;

try {
  const mongoose = require('mongoose');

  function connectToDatabase(uri, option) {
    console.log('connection state++ ', mongoose.connection.readyState);
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      console.log('connection reused');
      return Promise.resolve();
    } else {
      console.log('connection created once again');
      return mongoose.connect(uri, option);
    }

  }

  exports.handler = (event, context, callback) => {

    cb = callback;
    context.callbackWaitsForEmptyEventLoop = false;

    //for trigger
    if (event.fromTrigger) {
      console.log('fromTrigger');
      callback(null, 'done');
      return;
    }

    const constant = require('./constant');
    const managerModel = require('./model').Manager;
    const response = {headers: {'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'}};


    // check for cognito sub
    console.log(event);
    const auth = getSub(() => event.requestContext.authorizer.principalId);
    console.log(auth);
    const clientId = (auth) ? JSON.parse(auth).sub : auth;
    if (!clientId) {
      sendUnAuthorized();
      return;
    }


    const query = event.queryStringParameters;
    const data = query && query.data && JSON.parse(query.data);
    if (!data) {
      sendServerError({err: 'missing queryStringParameters'});
      return;
    }

    //connect to db
    connectToDatabase(constant.DB.URL, {poolSize: constant.DB.POOL_SIZE}).then(fetchManager).catch(sendServerError);

    function sendServerError(error) {
      console.error('error +++', error);
      Object.assign(response, {
        statusCode: error.statusCode || 500,
        body: 'Internal server error'
      });
      callback(null, response);
    }


    function fetchManager() {
      const query = {clientId: clientId, role: constant.DB.Manger, isDeleted: 0};
      console.log(query);
      if (data.filter && data.filter.search) {
        console.log("filter data exists");
        query.name = {$regex: `.*${data.filter.search}.*`};
        console.log('searching');
      }
      const pageNumber = data.page || 1;
      const pageLimit = data.limit || 10;

      console.log('call paginate');
      managerModel.paginate(query, {
        page: pageNumber,
        limit: pageLimit,
        populate: 'teams',
        sort: {'created_at': -1}
      }, function (err, managers) {

        console.log(err, managers);
        if (err) {
          sendServerError(err)
        } else {
          console.log(managers);
          Object.assign(response, {
            statusCode: 200,
            body: JSON.stringify(managers)
          });
          callback(null, response);
        }

      });
    }

    function getSub(fn) {
      let value;
      try {
        value = fn();
      } catch (e) {
        value = false;
      } finally {
        return value
      }
    };

    function sendUnAuthorized() {
      callback(null, Object.assign(response, {
        statusCode: 403,
        body: {}
      }));
    }

  };
} catch (err) {
  console.error('error +++', err);
  const response = {
    headers: {'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'},
    statusCode: err.statusCode || 500,
    body: 'Internal server error'
  };
  cb(null, response);
}

// manager_fetch.zip
