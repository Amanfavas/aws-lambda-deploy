module.exports = {
  "DB": {
    "URL": "mongodb://vignesh:Vignesh123@deliforce-shard-00-00-6geto.mongodb.net:27017," +
    "deliforce-shard-00-01-6geto.mongodb.net:27017," +
    "deliforce-shard-00-02-6geto.mongodb.net:27017/deliforce?replicaSet=deliforce-shard-0&authSource=admin&ssl=true",
    "Manger": 2,
    "POOL_SIZE": 2
  },
  "STATUS": {}
}

//{"fromTrigger":1}
