const AWS = require('aws-sdk');
const constant = require('./constant').AWS;
AWS.config.update({region: constant.region});
const options = {apiVersion: '2016-04-18',accessKeyId:constant.accessKeyId , secretAccessKey:constant.secretAccessKey}
const cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider(options);



module.exports = {
  updateUser: function (user , userName) {
    return new Promise((resolve, reject) => {


      // Define User Attributes
      const attributeList = [];

      if(user.name){
        const dataName = {
          "Name": 'name',
          "Value": user.name
        };
        attributeList.push(dataName)
      }

      if(user.email){
        const dataEmail = {
		  "Name": "email",
		  "Value": user.email
		    };
        attributeList.push(dataEmail)
      }

      if(user.phone){
        const dataPhone = {
          "Name": 'phone_number',
          "Value": user.phone.replace(' ', '')
        };
        attributeList.push(dataPhone);
      }


      //TODO we cannot reset password find how to handle this scenario
      /*if(user.password){
        const dataPassword = {
          "Name": 'password',
          "Value":user.password
        };
        attributeList.push(dataPassword);
      }*/


      var params = {
        UserAttributes:attributeList,
        UserPoolId: constant['userPoolId'], /* required */
        Username: userName /* required */
      };
      cognitoidentityserviceprovider.adminUpdateUserAttributes(params, function(err, data) {
        if (err) reject(err); // an error occurred
        else resolve();           // successful response
      });

    });
  }
};
