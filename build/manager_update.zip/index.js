let cb;
const result = require('./result');

try {

  /*const callback = (err, data) => {
	  console.log(err, data);
	  };
  const event = require('../../mock').admin.event;
  event.body = require('../../mock').data.managerEdit;*/

   exports.handler = (event, context, callback) => {

    cb = callback;
    context.callbackWaitsForEmptyEventLoop = false;

    //imports
    const db = require('./db').connect();
    const manager = require('./manager');
    const helper = require('./util');

    //for trigger
    if (helper.checkFromTrigger(cb, event)) return;


    // check for cognito sub
    const principals = helper.getPrincipals(cb, event);
    if (!principals.sub) return;


    db.then(() => manager.updateManager(cb, event, principals.sub)).catch(sendError);


    function sendError(error) {
      console.error('error +++', error);
      helper.sendServerError(cb);
    }


 };

} catch (err) {
  console.error('error ++++++', err);
  result.sendServerError(cb);
}
// manager_add.zip
// manager not allowed
