const constant = require('./constant');
const managerModel = require('./model').manager;
const cognito = require('./cognito');
const result = require('./result');
const helper = require('./util');
const permission = require('./permission');
const mongoose = require('mongoose');


//TODO currently we are only updating permission data of manager

module.exports = {
  updateManager: checkDuplicate
};


function checkDuplicate(cb, event, clientId) {
  const data = helper.getBodyData(event);
  if (!data) {
    result.invalidInput(cb);
    return
  }

  const managerId = mongoose.Types.ObjectId(data['_id']);
  if (!managerId) {
    result.invalidInput(cb);
    return
  }

  managerModel.findOne({"$or": [{email: data.email}, {phone: data.phone}], _id: {$ne: managerId}}, (err, manager) => {
    if (err) {
      result.sendServerError(cb)
    } else if (manager) {
      sendDuplicate(manager);
    } else {
      validateManagerData(data, cb, clientId, managerId);
    }
  });


  function sendDuplicate(manager) {
    if (manager.email === data.email) {
      result.sendDuplicateEmail(cb);
    } else {
      result.sendDuplicatePhone(cb);
    }
  }
}


//before create cognito user do validate
function validateManagerData(data, cb, clientId, managerId) {
  //deleted _id
  delete data['_id'];
  const testData = Object.assign({}, data, {clientId: clientId, cognitoSub: 'mockdata'});
  const adminData = new managerModel(testData);

  adminData.validate((err) => {
    if (err) {
      managerError(err, cb);
    } else {
      cognitoManager(data, cb, clientId, managerId);
    }
  })
}


function findCognitoDiff(a, b) {
  const result = {};
  if (a['email'] !== b['email']) {
    result['email'] = b['email']
  }
  if (a['password'] !== b['password']) {
    result['password'] = b['password'];
  }
  if (a['phone'] !== b['phone']) {
    result['phone'] = b['phone'];
  }
  if (a['name'] !== b['name']) {
    result['name'] = b['name']
  }
  return result;
}

function cognitoManager(data, cb, clientId, managerId) {

  managerModel.findOne({_id: managerId}, (err, managerData) => {
    if (err) {
      result.sendServerError(cb);
    } else {
      const filterData = Object.assign({}, data,
        {
          clientId: clientId, role: managerData.role, isDelete: 0,
          cognitoSub: managerData.cognitoSub, password: managerData.password
        });

      const diff = findCognitoDiff(managerData, data);
      if (helper.isEmptyObj(diff)) {
        updateManager(filterData, cb, managerId);
      } else {
        updateCognito(diff, filterData, managerData['email']);
      }
    }

  });


  function updateCognito(update, data, userName) {
    cognito.updateUser(update, userName).then(() => {
      updateManager(data, cb, managerId);
    }).catch((err) => sendCognitoError(err, cb));
  }

}


function updateManager(data, cb, managerId) {

  managerModel.update({_id: managerId}, data, {runValidators: true})
    .then((manager) => {
      setPermission(data, manager, cb);
    }).catch((err) => managerError(err, cb));
}


function managerError(err, cb) {
  const errors = err.errors;
  if (errors && errors.teams) {
    result.sendTeamMandatory(cb)
  } else {
    result.sendServerError(cb);
  }
}

function setPermission(data, manager, cb) {
  permission.setPermission(data.permissions, data.cognitoSub)
    .then(() => {
      result.sendSuccess(cb, manager);
    })
    .catch((err) => {
      console.log('permission not setted', err);
      result.sendSuccess(cb, manager);
    })
}


function sendCognitoError(err, cb) {
  console.log('cognito error', err);
  const cognito = constant.COGNITO_ERROR;
  if (err.code === cognito.PASSWORD_INVALID) {
    result.sendPasswordInvalid(cb);
  } else if (err.code === cognito.EMAIL_EXIST) {
    result.sendDuplicateEmail(cb);
  } else if (err.code === cognito.INVALID_DATA) {
    console.log('invalid phone or email');
    result.sendInvalidPhoneOrEmail(cb);
  } else {
    result.sendServerError(cb);
  }
}
