const result = require('./result');
const helper = require('./util');
const constant = require('./constant')();
const taskModel = require('./model');
const isIt = constant.isIt;

module.exports = {
  //princial  manager- clientId , role , sub , teams
  //admin - sub , role

  deleteTask:(event, cb, principals) => {
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : null;
    if (!clientId) {
      result.sendUnAuth(cb);
    } else {
      const data = helper.getQueryData(event);
      if (!data) {
        result.invalidInput(cb);
      }
      taskModel.update({_id: data._id, clientId: clientId}, {isDeleted: isIt.YES}).then((data) => {
        result.sendSuccess(cb, data);
      }).catch((err) => {
        result.sendServerError(cb);
      });
    }
  }
};


