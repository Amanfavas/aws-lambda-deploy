const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant')();
const isIt = constant.isIt;
const tables = constant.TABLES;

const taskSchema = new Schema({
  isDeleted:{type:Number,default:isIt.NO}
});

module.exports = mongoose.model(tables.TASK, taskSchema);
