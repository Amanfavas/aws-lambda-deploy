const result = require('./result');
const driverModel = require('./model').driverModel;
const TaskModel = require('./model').TaskModel;
const helper = require('./util');
const constant = require('./constant')();
const mongoose = require('mongoose');

module.exports = {
  deleteDriver: (event, cb, principals) => {
    console.log("hello hello");
    const data = helper.getQueryData(event);
    console.log(data._id);
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
    if (!data) {
      result.invalidInput(cb);
    } else {
      fetchTask(data).then((task) => {
        console.log(task);
        if (task) {
          result.driverHasTask(cb);
        }
        else {
          console.log(clientId,data._id);
          return driverModel.update({
            _id: mongoose.Types.ObjectId(data._id),
            clientId: clientId
          }, {isDeleted: constant.isIt.YES})
            .then((data) => {
              result.sendSuccess(cb, data);
            });
        }
      }).catch((err)=>{
        console.log(err);
        result.sendServerError(cb);
      });
    }
  }
};
//console.log("Hi,This is a Test");
function fetchTask(data) {
  console.log(data._id);
  return TaskModel.findOne({$and: [{driver: mongoose.Types.ObjectId(data._id)},
    {taskStatus:{$in:[constant.TASK_STATUS.INPROGRESS,constant.TASK_STATUS.STARTED,constant.TASK_STATUS.ASSIGNED,constant.TASK_STATUS.ACCEPTED]}}]});
}



