const result = require('./result');
const driverModel = require('./model').driverModel;
const helper = require('./util');
const mongoose= require('mongoose');
const constant = require('./constant')();
const role = constant.ROLE;
const isIt = constant.isIt;
const empty = require('is-empty');
const moment = require('moment');
const driverStatus = constant.DRIVER_STATUS;

module.exports = {

  getDrivers: (event, cb, principals) => {
    const data = helper.getQueryData(event);
    console.log(data);
    if (!data) {
      result.invalidInput(cb);
    }
    const query = formQuery(principals, data);
    var startDate;
    var dateMidnight;
    const businessType = data.businessType;
    //for daystarting Time
    if (!empty(data.filter.dateFilter)) {
      startDate = new Date(data.filter.dateFilter);
      startDate.setSeconds(0);
      startDate.setHours(0);
      startDate.setMinutes(0);
      //for day End Time
      dateMidnight = new Date(data.filter.dateFilter);
      dateMidnight.setHours(23);
      dateMidnight.setMinutes(59);
      dateMidnight.setSeconds(59);
    }


    if (empty(data.businessType)) {
      result.businessMissing(cb);
      return;
      //query.$match.$and.push({'assignTeam': mongoose.Types.ObjectId(data.filter.TeamsFilter)});
    }
    if (!empty(data.filter.TeamsFilter)) {
      query.$match.$and.push({'assignTeam': mongoose.Types.ObjectId(data.filter.TeamsFilter)});
    }
    if (!empty(data._id)) {
      query.$match.$and.push({'_id': mongoose.Types.ObjectId(data._id)});
    }
    console.log(query);
    // if(!empty(data.filter.TeamsFilter)){
    driverModel.aggregate([query, {
      $lookup: {
        from: "tasks",
        localField: "_id",
        foreignField: "driver",
        as: "taskDetails"
      }
    },

      {"$unwind": {"path": "$taskDetails", "preserveNullAndEmptyArrays": true}},

      {$sort: {'taskDetails.priority': -1}},
      {
        "$group": {
          "_id": "$_id",
          "name": {"$first": "$name"},
          "email": {"$first": "$email"},
          "phone": {"$first": "$phone"},
          "password": {"$first": "$password"},
          "role": {"$first": "$role"},
          "currentLocation": {"$first": "$currentLocation"},
          "lastName": {"$first": "$lastName"},
          "notes": {"$first": "$notes"},
          "image": {"$first": "$image"},
          "assignTeam": {"$first": "$assignTeam"},
          "transportType": {"$first": "$transportType"},
          "tranportDesc": {"$first": "$tranportDesc"},
          "driverStatus": {"$first": "$driverStatus"},
          "licencePlate": {"$first": "$licencePlate"},
          "kolor": {"$first": "$kolor"},
          "isDeleted": {"$first": "$isDeleted"},
          "taskDetails": {"$push": "$taskDetails"}
        }
      }
    ])
      .then((data) => {
        console.log(data);
        console.log(startDate);
        console.log(dateMidnight);
        console.log(businessType);
        for (var i = 0; i < data.length; i++) {
          for (var j = 0; j < data[i].taskDetails.length; j++) {
            //|| data[i].taskDetails[j].businessType !== businessType

            if (!(data[i].taskDetails[j].date > startDate && data[i].taskDetails[j].date < dateMidnight) || data[i].taskDetails[j].isDeleted === 1 || data[i].taskDetails[j].businessType !== businessType) {
              //console.log(data[i].taskDetails[j].date);
              data[i].taskDetails.splice(j, 1);
              j = (j = 0) ? 0 : j - 1;
            }
          }
        }
        result.sendSuccess(cb, data);
      }).catch((error) => {
      console.log(error);
      result.sendServerError(cb)
    });


  }
};


function formQuery(principals, qryData) {


  var defaultQuery = {
    '$match': {
      '$and': [

        {"role": role.DRIVER},
        {"isDeleted": isIt.NO},
        {"driverStatus": {$ne: driverStatus.BLOCKED}}


      ]

    }
  };

  var query1 = defaultQuery;

  if (!empty(qryData.filter.search)) {
    query1.$match.$and.push({name: {$regex: `.*${qryData.filter.search}.*`}}),

      console.log('searching');
  }




  // if (qryData.filter && qryData.filter.search) {
  //   //TODO This should be optimised with common search & fields structure. ex: fields:['teamName','description']
  //   query.name = {$regex: `.*${qryData.filter.search}.*`};
  // }

  //add auth query
  if (helper.isAdmin(principals)) {
    query1.$match.$and.push({'clientId': principals['sub']});

  } else {
    //manager
    query1.$match.$and.push({'clientId': principals['clientId']});
    var teams= principals['teams'];
    teams= teams.map((team)=>{
      return mongoose.Types.ObjectId(team);
    });

    query1.$match.$and.push({assignTeam: {'$in': teams}});
  }
  console.log(query1);
  return query1;
}



