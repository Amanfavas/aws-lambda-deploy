const result = require('./result');
const preferenceModel = require('./model');
const helper = require('./util');

module.exports = {
  fetchPreference:(event, cb, principals) => {
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
    preferenceModel.findOne({clientId: clientId}, function (err, preference) {
      console.log(clientId);
      //  console.log(err, preference);
      if (err) {
        result.sendServerError(err);
      } else {
        result.sendSuccess(cb, preference)
      }
    });
  }
};









