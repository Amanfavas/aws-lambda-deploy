var mongoose = require('mongoose');
var Schema = mongoose.Schema;
const constant = require('./constant')();
const tables = constant.TABLES;

//action=[{code:1,exist:0/1,mandatory:0/1}]
//autoAllocation:{enable:true/false,method:1/2/3,expire:anyNumber,retry:anyNumber}

const preferenceSchema = new Schema({
  userId: String,
  customizeAgentTextAs: Schema.Types.Mixed,
  customizeManagerTextAs: Schema.Types.Mixed,
  dashboardLanguage: Schema.Types.Mixed,
  customerTrackingLangauge: Schema.Types.Mixed,
  distance: Schema.Types.Mixed,
  timeZone: Schema.Types.Mixed,
  cognitoSub: {type: String, required: true},
  clientId: {type: String, required: true},
});


module.exports = mongoose.model(tables.PREFERENCE, preferenceSchema);
