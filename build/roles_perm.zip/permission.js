const permissionModel = require('./model').permission;
const userModel = require('./model').user;
const constant = require('./constant')();
const result = require('./result');

module.exports = {

  fetchPrivilage: function (event, sub, cb) {
    return findUser(sub).then((user) => {
      if (!user) {
        console.log('user not found for sub');
        result.sendUnAuth(cb);
      } else {
        console.log('User++', user);
        return checkPermission(user.toObject(), cb);
      }
    });
  }
};

function findUser(sub) {
  return userModel.findOne({cognitoSub: sub});
}

/*function getmoduleAction(event) {
  const path = event.path;
  const method = event.httpMethod;
  if (path && method) {
    const pathConst = path.substr(1).replace('/', '_') + '_' + method;
    console.log('moduleAction+++', pathConst.toUpperCase());
    return constant.API_PRIVILAGE[pathConst.toUpperCase()];
  }
}*/

function checkPermission(user, cb) {
  // to save db opt time allow all for admin. If admin is not accessible to all resource remove this.
  const userId = user['cognitoSub'];
  const roleId = user['role'];
  if (user.role === constant.ROLE.ADMIN) {
    result.sendSuccess(cb, {role: roleId});
  } else {
    console.log(userId, roleId);
    //permissionModel.find({}).then((d)=>console.log(d));
    return permissionModel.find({principalId: {$in: [userId, roleId]}})
      .then((permissions) => {
        console.log(permissions.length, '+++');
        const trimPermission = permissions.map((per) => ({action: per['moduleAction'], grant: per['grant']}));
        result.sendSuccess(cb, {permission: trimPermission, role: roleId});
      });
  }

  /*function checkAccess(permissons) {
	const roleC = constant.PRINCIPAL;
	if (!permissons.length) {
	  console.log('no access found in db');
	  return Promise.reject();
	} else {
	  return Promise.resolve(user);
	  // TODO currently we are not adding deny rule so no need to check for this
	  /!*permissons.forEach((perm)=>{
		if(perm.principalType===roleC.USER){

		}else if(perm.principalType===roleC.ROLE) {

		}
	  });*!/
	}
  }*/
}
