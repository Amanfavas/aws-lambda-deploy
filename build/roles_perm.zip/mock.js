module.exports = {

  //cognito authorizer event not lambda authorizer
  admin: {
    event: {
      "resource": "/userpermission",
      "path": "/userpermission",
      "httpMethod": "GET",
      "headers": {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9",
        "Authorization": "eyJraWQiOiIyN3NYaU1FcU5GQ2JqTGNXM1dzc0M2cG5KZ2Z1MDd6MlJBTFR0MFR5ZHRBPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJiM2E1MGNjNC04ZGU1LTRlY2MtOTM0ZC1iM2NhNjYzOTU5MTciLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbVwvYXAtc291dGgtMV84RmdGVUxzVG8iLCJwaG9uZV9udW1iZXJfdmVyaWZpZWQiOmZhbHNlLCJjb2duaXRvOnVzZXJuYW1lIjoiYjNhNTBjYzQtOGRlNS00ZWNjLTkzNGQtYjNjYTY2Mzk1OTE3IiwiYXVkIjoiN2JlNXRqZWF0YmlmcWs0ZDFhcnFpOTBtNDUiLCJldmVudF9pZCI6IjYyOGZjNTRkLTI5MjgtMTFlOC05MWM3LTczOTliMTdhYmNlZSIsInRva2VuX3VzZSI6ImlkIiwiYXV0aF90aW1lIjoxNTIxMjExNDA2LCJuYW1lIjoic3RldmUiLCJwaG9uZV9udW1iZXIiOiIrOTEzMjMyMjM0MjM0MjMiLCJleHAiOjE1MjEyMTUwMDYsImlhdCI6MTUyMTIxMTQwNiwiZW1haWwiOiJzdGV2ZUBnbWFpbC5jb20ifQ.HdApPC4bHKVxQA4XdkPnFq_e8zpdiNLfOctZmnL18lM1yPmtDoNeJWsLb3yhDenc3TFVq4k_tCUWcoBWYigco0_FocJPCD34TNXOhZfplJrnMN9SYyBMxwz01TwEePFPzE0XfcGxW-vXiExe5E2HQt2uClZcOEqVg3sADQ_L7CDdMJMZN5equyA2i6TOhABa_vI_ICdMEky0UcrfPegHoTZ__aLorrxrMzXOGY_-8rAeeiaf9fDuWx68isiNmmumehp_YJP3sOGtZui1E-XeFIR2GvX1Zj2CHPu1p5o7TQPEGZLrhYShAB1yBU-IUBvMsYF9YIbxSbyP12E7x_mSIQ",
        "cache-control": "no-cache",
        "CloudFront-Forwarded-Proto": "https",
        "CloudFront-Is-Desktop-Viewer": "true",
        "CloudFront-Is-Mobile-Viewer": "false",
        "CloudFront-Is-SmartTV-Viewer": "false",
        "CloudFront-Is-Tablet-Viewer": "false",
        "CloudFront-Viewer-Country": "IN",
        "Host": "8qccyeh61h.execute-api.ap-south-1.amazonaws.com",
        "postman-token": "fb819a2a-af3c-d7b9-1862-f559a60d5004",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
        "Via": "2.0 415c421af891d7c3f4ade60aba542014.cloudfront.net (CloudFront)",
        "X-Amz-Cf-Id": "BRRPPgatwTS5SiBEXwkUH9D17wy8I2g4OkPfaN6RdryzkR92ClezGg==",
        "X-Amzn-Trace-Id": "Root=1-5aabdbcf-1fc5db488f915eb013738b90",
        "X-Forwarded-For": "106.51.73.130, 54.239.160.79",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Proto": "https"
      },
      "queryStringParameters": null,
      "pathParameters": null,
      "stageVariables": null,
      "requestContext": {
        "resourceId": "tl8t4j",
        "authorizer": {
          "claims": {
            "sub": "b3a50cc4-8de5-4ecc-934d-b3ca66395917",
            "email_verified": "true",
            "iss": "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_8FgFULsTo",
            "phone_number_verified": "false",
            "cognito:username": "b3a50cc4-8de5-4ecc-934d-b3ca66395917",
            "aud": "7be5tjeatbifqk4d1arqi90m45",
            "event_id": "628fc54d-2928-11e8-91c7-7399b17abcee",
            "token_use": "id",
            "auth_time": "1521211406",
            "name": "steve",
            "phone_number": "+91323223423423",
            "exp": "Fri Mar 16 15:43:26 UTC 2018",
            "iat": "Fri Mar 16 14:43:26 UTC 2018",
            "email": "steve@gmail.com"
          }
        },
        "resourcePath": "/userpermission",
        "httpMethod": "GET",
        "requestTime": "16/Mar/2018:14:59:27 +0000",
        "path": "/Development/userpermission",
        "accountId": "221980681332",
        "protocol": "HTTP/1.1",
        "stage": "Development",
        "requestTimeEpoch": 1521212367598,
        "requestId": "9f7db163-292a-11e8-b75c-9b5afb330dff",
        "identity": {
          "cognitoIdentityPoolId": null,
          "accountId": null,
          "cognitoIdentityId": null,
          "caller": null,
          "sourceIp": "106.51.73.130",
          "accessKey": null,
          "cognitoAuthenticationType": null,
          "cognitoAuthenticationProvider": null,
          "userArn": null,
          "userAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
          "user": null
        },
        "apiId": "8qccyeh61h"
      },
      "body": null,
      "isBase64Encoded": false
    }
  },
  manager: {
    event: {
      "resource": "/userpermission",
      "path": "/userpermission",
      "httpMethod": "GET",
      "headers": {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9",
        "Authorization": "eyJraWQiOiIyN3NYaU1FcU5GQ2JqTGNXM1dzc0M2cG5KZ2Z1MDd6MlJBTFR0MFR5ZHRBPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2Njc1NDY5Mi1hNjFmLTRhMTItOWE3Yi03NjZkNTllMjdlZGYiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbVwvYXAtc291dGgtMV84RmdGVUxzVG8iLCJwaG9uZV9udW1iZXJfdmVyaWZpZWQiOmZhbHNlLCJjb2duaXRvOnVzZXJuYW1lIjoiNjY3NTQ2OTItYTYxZi00YTEyLTlhN2ItNzY2ZDU5ZTI3ZWRmIiwiYXVkIjoiN2JlNXRqZWF0YmlmcWs0ZDFhcnFpOTBtNDUiLCJldmVudF9pZCI6ImJlODc0YWI0LTI5MmItMTFlOC1iNzE5LTNmMjA2MTZmMDFjYSIsInRva2VuX3VzZSI6ImlkIiwiYXV0aF90aW1lIjoxNTIxMjEyODQ5LCJuYW1lIjoicmFqYXMiLCJwaG9uZV9udW1iZXIiOiIrOTE0ODIzMzIyMjMyMyIsImV4cCI6MTUyMTIxNjQ0OSwiaWF0IjoxNTIxMjEyODQ5LCJlbWFpbCI6InJhamFzQGdtYWlsLmNvbSJ9.DnfiPKgh3knuBnleYSN-azrlXKcs4bSClAATX2TObd07aTVxr0B5-bP38zAuuTliMEkxLGQviETLyqJDhtq-9nNicv_w3V4hWPoyjzdtqz_tFZK06pDRWBea6_OFDYyNRmaLliGYTMF_oYuEWFACV2KUO2WtrZHs6XNwxADESJb3pSimdppfJlhIYW2gsHQbX0ZntvqXsCk3H4NrJbbrv810BLbZF_5JxIyMbj2LrfsRSKr61pfLUxmj0KdM9OYYnoE5VxkUtjEWa4EQo5QL5jRxE8UXParGvxziaOV0k026d4GKS8Yb_RQ4JC7V42SulOblhSzDCT8WqGKMxEWfrA",
        "cache-control": "no-cache",
        "CloudFront-Forwarded-Proto": "https",
        "CloudFront-Is-Desktop-Viewer": "true",
        "CloudFront-Is-Mobile-Viewer": "false",
        "CloudFront-Is-SmartTV-Viewer": "false",
        "CloudFront-Is-Tablet-Viewer": "false",
        "CloudFront-Viewer-Country": "IN",
        "Host": "8qccyeh61h.execute-api.ap-south-1.amazonaws.com",
        "postman-token": "f15ba921-d9b8-d660-38f2-24aeaaab7a04",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
        "Via": "2.0 13c3e41174b4e6fd31acc9612823c449.cloudfront.net (CloudFront)",
        "X-Amz-Cf-Id": "9QP5RrD1_OGFLtRyMq_7k6LYJ0i4jmBMvDAZge9ILYF-a9U-AH2CaQ==",
        "X-Amzn-Trace-Id": "Root=1-5aabddde-5bc7996cbe18123e538e9dee",
        "X-Forwarded-For": "106.51.73.130, 54.239.160.112",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Proto": "https"
      },
      "queryStringParameters": null,
      "pathParameters": null,
      "stageVariables": null,
      "requestContext": {
        "resourceId": "tl8t4j",
        "authorizer": {
          "claims": {
            "sub": "66754692-a61f-4a12-9a7b-766d59e27edf",
            "email_verified": "true",
            "iss": "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_8FgFULsTo",
            "phone_number_verified": "false",
            "cognito:username": "66754692-a61f-4a12-9a7b-766d59e27edf",
            "aud": "7be5tjeatbifqk4d1arqi90m45",
            "event_id": "be874ab4-292b-11e8-b719-3f20616f01ca",
            "token_use": "id",
            "auth_time": "1521212849",
            "name": "rajas",
            "phone_number": "+9148233222323",
            "exp": "Fri Mar 16 16:07:29 UTC 2018",
            "iat": "Fri Mar 16 15:07:29 UTC 2018",
            "email": "rajas@gmail.com"
          }
        },
        "resourcePath": "/userpermission",
        "httpMethod": "GET",
        "requestTime": "16/Mar/2018:15:08:14 +0000",
        "path": "/Development/userpermission",
        "accountId": "221980681332",
        "protocol": "HTTP/1.1",
        "stage": "Development",
        "requestTimeEpoch": 1521212894307,
        "requestId": "d96f1b42-292b-11e8-a24d-ff5f37a2db32",
        "identity": {
          "cognitoIdentityPoolId": null,
          "accountId": null,
          "cognitoIdentityId": null,
          "caller": null,
          "sourceIp": "106.51.73.130",
          "accessKey": null,
          "cognitoAuthenticationType": null,
          "cognitoAuthenticationProvider": null,
          "userArn": null,
          "userAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
          "user": null
        },
        "apiId": "8qccyeh61h"
      },
      "body": null,
      "isBase64Encoded": false
    }
  }
}
