const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant')();
const tables = constant.TABLES;

const taskLogSchema = new Schema({
});

module.exports = mongoose.model(tables.TASK_LOG, taskLogSchema);
