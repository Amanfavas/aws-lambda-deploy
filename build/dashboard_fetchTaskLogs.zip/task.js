const result = require('./result');
const taskLog = require('./model');
const helper = require('./util');
const mongoose = require('mongoose');


module.exports = {


  fetchTaskLog: (event, cb, principals) => {
    const data = helper.getQueryData(event);
    console.log(data);
    if (!data) {
      result.invalidInput(cb);
    }
    //const query = formQuery(principals, data);
    const clientId = helper.isAdmin(principals) ? principals['sub'] : principals.clientId;
    //Object.assign({TaskId: mongoose.Types.ObjectId(data.TaskId),clientId:clientId})
    taskLog.find({clientId: clientId, taskId: data.taskId})
      .then((data) => {
        result.sendSuccess(cb, data);

      }).catch(() => {
      result.sendServerError(cb)
    });

  }
};


// function formQuery(principals, qryData) {
//   const query;
//  console.log(principals);
//   //add auth query
//   if (helper.isAdmin(principals)) {
//     query['clientId'] = principals['sub'];
//   } else {
//     //manager
//     console.log(principals)
//     query['clientId'] = principals.clientId;
//     //assign Team is needed?
//     //query['assignTeam'] = {'$in': principals['teams']};
//   }
//   console.log(query);
//   return query;
// }
