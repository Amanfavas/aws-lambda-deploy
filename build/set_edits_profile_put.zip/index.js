const uuid = require('uuid');
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();


exports.handler = (event, context, callback) => {
    // const clientId = event.requestContext.authorizer.claims.sub;
    const clientId = '1234567899'
   	const data = JSON.parse(event.body);
   	console.log(data);
 
		var params = {
		TableName: 'Team',
		Item: data,
		key : {
		    "teamId":data.body.teamId
		}
	};

	dynamoDb.put(params, (error) => {
		if (error) {
			console.error(error);
			callback(null, {
				statusCode: error.statusCode || 501,
				headers: {'Content-Type': 'text/plain','Access-Control-Allow-Origin': '*'},
				body: 'Couldn\'t create the product item.',
			});
			return;
		}
		const response = {
			headers:{'Access-Control-Allow-Origin': '*'},
			statusCode: 200,
			body: JSON.stringify(params.Item),
		};
		callback(null, response);	
	});
};

  