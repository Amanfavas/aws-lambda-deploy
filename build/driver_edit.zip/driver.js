const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const driverModel = require('./model');


module.exports = {

  checkDuplicate: (event, cb, principals) => {
    const data = helper.getBodyData(event);

    if (!data) {
      result.invalidInput(cb);
    } else {
      const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
      //{$or: [{'email': data.email}, {'phone': data.phone},{ _id: { $ne: mongoose.Types.ObjectId(data._id) }}]}
      console.log(data._id);
      driverModel.findOne({$or: [{email: data.email}, {phone: data.phone}], _id: {$ne: mongoose.Types.ObjectId(data._id)}}, (err, driver) => {
        if (err) {
          result.sendServerError(cb);
        }  else if (driver) {
          console.log(driver);
          if (driver.email === data.email) {
            console.log('duplicate key of email');
            result.sendDuplicateEmail(cb);
          } else {
            console.log('duplicate key of phone');
            result.sendDuplicatePhone(cb);
          }
        } else {
          console.log('update driver');
          upsertDriver(data, clientId, cb);
        }
      });
    }
  }
};


function upsertDriver(data, clientId, cb) {
  const callback = cb;
  Object.assign(data, {'clientId': clientId});
  const _id = data._id;
  delete data._id;
  console.log(clientId, _id);
  driverModel.update({_id: _id, clientId: clientId}, data, {
    upsert: true,
    setDefaultsOnInsert: true
  }, function (error, data) {
    if (error) {
      console.log(error);
      console.log('error block');
      handlerError(error, callback);
    }
    else {
      console.log('success block');
      result.sendSuccess(callback, data);
    }
  });
}

function handlerError(error, cb) {

  const err = error.errors;
  if (err.email) {
    result.invalidEmail(cb);
  }
  else if (err.name) {
    result.invalidName(cb);
  }
  else if (err.phone) {
    result.invalidPhone(cb);
  }
  else if (err.password) {
    result.invalidPassword(cb);
  }
  else if (err.assignTeam) {
    result.TeamMandatory(cb);
  }
  else if (err.cognitoSub) {
    result.CagnitoSub(cb);
  }

  else {
    result.sendServerError(cb);
  }
}

//princial  manager- clientId , role , sub , teams
//admin - sub , role




