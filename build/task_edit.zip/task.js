const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const constant = require('./constant');
const model = require('./model');
const tasklogModel = model.tasklogModel;
const taskM = model.task;
const settingModel = model.settingModel;
const userModel = model.userModel;


module.exports = {

  //princial  manager- clientId , role , sub , teams
  //admin - sub , role

  editTask: (event, cb, principals) => {

    const data = helper.getBodyData(event);
    if (!data) {
      result.invalidInput(cb);
    } else {
      const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
      let userData;
      let taskData;
      checkDriver(data, clientId)
        .then((user) => {
          console.log('data++', JSON.stringify(data));
          console.log('user++', JSON.stringify(user));
          userData = user;
          return editTask(data, clientId, cb);
        }).then((oldtask,resultUpdate) => {
           taskData = resultUpdate;
           console.log('taskupdate++', JSON.stringify(resultUpdate));

           return createTasklog(oldtask, data , userData , principals.role);
        })
        .then(() => {
          result.sendSuccess(cb, taskData);
        })
        .catch((err) => {
          console.log('err++++ ', JSON.stringify(err));
          result.sendServerError(cb)
        });
    }
  }
};


function checkDriver(data, clientId) {
  return new Promise((resolve, reject) => {
    if (data.driver) {
      const driverObjId = mongoose.Types.ObjectId(data.driver);
      userModel.find({$or: [{_id: driverObjId}, {'cognitoSub': clientId}]})
        .then((response) => {
          const result = {adminName: '', driverName: ''};
          response.find((driver) => {
            driver = driver.toObject();
            if (driver._id.toString() === data.driver) {
              result.driverName = (driver.clientId === clientId) ? driver.name : '';
            }
            if (driver.cognitoSub === clientId) {
              result.adminName = driver.name;
            }
          });

          // check driverid is secured one
          if (result.driverName) resolve(result);
          else reject({message: 'invalid driver'});

        }).catch((err) => reject(err));
    } else {
      userModel.findOne({'cognitoSub': clientId})
        .then((response) => {
          const data = response.toObject();
          resolve({adminName: data.name, driverName: ''});
        }).catch((err) => reject(err));

    }
  });


}


function editTask(data, clientId, cb) {
  let updateResult;
  return new Promise((resolve,reject)=>{
    const taskModel = model.task.getTaskModel(data['businessType']);
    if (!taskModel) {
      reject('model not found for businessType');
    }
    data.clientId = clientId;
    const taskId = data._id;
    delete data._id;
    const query = {_id:mongoose.Types.ObjectId(taskId),clientId: clientId};
    taskModel.findOne(query,(err,taskFetch)=>{
      if(err){
        reject(err);

      }
      //console.log('datafrom db'+taskFetch);
      //console.log(taskFetch);
      taskModel.update(query, data, {multi: false, runValidators: true})
        .then((taskData)=>{
          updateResult=taskData;
          console.log('taskData++++ ', JSON.stringify(taskData));
          resolve(taskFetch,updateResult);
        }).catch((err)=>reject(err))
    });
  });
}

function createTasklog(oldTask , updateTask , ud, role) {

  const models = [];
  const taskLogStatus = constant.TASK_LOG_STATUS;
  const model = {
    user: ud.adminName,
    taskStatus: taskLogStatus.UPDATED,
    taskId: data._id,
    clientId: clientId,
    role: role
  };

  models.push(model);
  if(updateTask.taskStatus && oldTask.taskStatus !== updateTask.taskStatus ) {
    const model = {
      user: ud.adminName,
      taskStatus: updateTask.taskStatus,
      taskId: data._id,
      driverName: ud.driverName,
      clientId: clientId,
      role: role
    };
    models.push(model);
  }

  return tasklogModel.insertMany(models);
}
