const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const constant = require('./constant')();
const _ = require('lodash');
const model = require('./model');
const driverM = model.driverModel;
const isIt = constant.isIt;


module.exports = {
  getDriverStatus: (event, cb, principals) => {
    const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
    const query = formQuery(principals);
    driverM.aggregate([query, {
      $group: {
        '_id': '$driverStatus',
        count: {$sum: 1}
      }
    }]).then((data) => {
      console.log(data);
      const mockData = [{'_id': 1, count: 0}, {'_id': 2, count: 0}, {'_id': 3, count: 0}, {'_id': 4, count: 0}];
      var arrResult = _.map(mockData, function (obj) {
        return _.assign(obj, _.find(data, {
          _id: obj._id
        }));
      });
      result.sendSuccess(cb, arrResult);
    }).catch((err) => {
      console.log(err);
      result.sendServerError(cb);
    });
  }
};


function formQuery(principals) {
  // const defaultQuery = {isDeleted: isIt.NO}; //add all default values here
  // const query = defaultQuery;

  const defaultQuery = {
    $match: {
      $and: [{isDeleted: isIt.NO}]
    }
  };
  const query = defaultQuery;
  //add auth query
  if (helper.isAdmin(principals)) {

    query.$match.$and.push({'clientId': principals['sub']});
  } else {
    //manager

    query.$match.$and.push({'clientId': principals['clientId']});

    //ToDo teams arry must be ObjectId fromat(mongoose.Types.ObjectId)
    var teams = principals['teams'];
    teams = teams.map((team) => {
      return mongoose.Types.ObjectId(team);
    });
    query.$match.$and.push({assignTeam: {'$in': teams}});
  }
  console.log(query);
  return query;
}





// driver_getDriverStatus.zip
