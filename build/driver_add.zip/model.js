const mongoose=require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant')();
const isIt = constant.isIt;
const driverStatus = constant.DRIVER_STATUS;
const tables = constant.TABLES;
const role = constant.ROLE;

const driverSchema = new Schema({
  name: {type: String, required: true},
  lastName: {type: String},
  email: {type: String, required: true},//cognito validation
  phone: {type: String, required: true},//cognito validation(+91 32323)
  password: {type: String, required: true},
  assignTeam: {type: Schema.Types.ObjectId, ref: tables.TEAM, required: true},
  notes: String,
  image: {type: String},
  transportType: {type: Number},
  transportDesc: {type: String},
  licencePlate: {type: String},
  kolor: {type: String},
  role: {type: Number, required: true ,default :role.DRIVER},
  clientId: {type: String, required: true},
  currentLocation: Schema.Types.Mixed,
  driverStatus: {type: Number, default: driverStatus.OFFLINE},
  isDeleted: {type: Number, default: isIt.NO},
  cognitoSub: {type: String, required: true},
  created_at: {type: Date, default: Date.now}
},{ strite:false });

module.exports = mongoose.model(tables.DRIVER, driverSchema);













