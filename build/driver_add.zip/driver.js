const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const constant = require('./constant')();
const driverModel = require('./model');
const cognito = require('./cognito');

module.exports = {

  checkDuplicate: (event, cb, principals) => {
    const data = helper.getBodyData(event);

    if (!data) {
      result.invalidInput(cb);
    } else {
      const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];

      driverModel.findOne({$or: [{'email': data.email}, {'phone': data.phone}]}, (err, driver) => {
        if (err) {
          result.sendServerError(cb)
        } else if (driver) {
          console.log(driver);
          if (driver.email === data.email) {
            console.log('duplicate key of email');
            result.sendDuplicateEmail(cb);
          } else {
            console.log('duplicate key of phone');
            result.sendDuplicatePhone(cb);
          }
        } else {
          console.log('add driver');
          validateDriverData(data, clientId, cb);

        }
      });
    }
  }
};


//before create cognito user do validate
function validateDriverData(data, cb, clientId) {

  // cognitosub is mock here
  const testData = Object.assign({}, data, {clientId: clientId, cognitoSub: '23232332'});
  const driverData = new driverModel(testData);

  driverData.validate((err) => {
    if (err) {
      handlerError(err, cb);
    } else {
      createCognitoUser(data, cb, clientId);
    }
  })
}


function createCognitoUser(data, clientId, cb) {
  cognito.createUser(data).then((cognitoUser) => {
    if (!cognitoUser.userSub) {
      return Promise.reject('usersub not found');
    } else {
      console.log('driver Sub ' + cognitoUser.userSub);
      addDriver(data, clientId, cb, cognitoUser.userSub);
    }
  }).catch((err) => sendCognitoError(err, cb));
}

function sendCognitoError(err, cb) {
  console.log('cognito error', err);
  const cognito = constant.COGNITO_ERROR;
  if (err.code === cognito.PASSWORD_INVALID) {
    result.invalidPassword(cb);
  } else if (err.code === cognito.EMAIL_EXIST) {
    result.sendDuplicateEmail(cb);
  } else if (err.code === cognito.INVALID_DATA) {
    console.log('invalid phone or email');
    result.invalidPhone(cb);
  } else {
    result.sendServerError(cb);
  }
}


// dummy  driver location data.
// in tookens they stored the location of driver is mandatory while creating driver
const driverMarker = [
  {
    'lat': 12.9852629,
    'lng': 77.7434198,
  },
  {
    'lat': 12.9817595,
    'lng': 77.7521271,
  },
  {
    'lat': 12.9894858,
    'lng': 77.7337725,
  },
  {
    'lat': 12.9944596,
    'lng': 77.7225265,
  },
  {
    'lat': 12.9794981,
    'lng': 77.7287335,
  },
  {
    'lat': 12.989065,
    'lng': 77.7416316,
  }];

Array.prototype.sample = function () {
  return this[Math.floor(Math.random() * this.length)];
};

function addDriver(data, clientId, cb, sub) {
  const callback = cb;
  Object.assign(data, {'clientId': clientId, cognitoSub: sub});
  const newDriver = new driverModel(data);
  newDriver.currentLocation = driverMarker.sample();
  newDriver.save(function (error, data) {
    if (error) {
      console.log(error)
      console.log('error block')
      handlerError(error, callback)
    }
    else {
      console.log('success block')
      result.sendSuccess(callback, data)
    }
  })
}

function handlerError(error, cb) {

  const err = error.errors;
  if (err.email) {
    result.invalidEmail(cb);
  }
  else if (err.name) {
    result.invalidName(cb)
  }
  else if (err.phone) {
    result.invalidPhone(cb)
  }
  else if (err.password) {
    result.invalidPassword(cb)
  }
  else if (err.assignTeam) {
    result.TeamMandatory(cb)
  }
  else if (err.cognitoSub) {
    result.CagnitoSub(cb)
  }

  else {
    result.sendServerError(cb);
  }
}

//princial  manager- clientId , role , sub , teams
//admin - sub , role




