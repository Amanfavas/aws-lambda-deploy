const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const managerSchema = new Schema({
  name: {type: String, required: true},
  lastName: {type: String},
  email: {type: String, required: true},//cognito validation
  phone: {type: String, required: true},//cognito validation(+91 32323)
  password: {type: String, required: true},//cognito min 8 char ,alpha(upper,lower) numeric, special characterassignTeam: {type :Schema.Types.ObjectId , ref:'team' , required:true},
  //managers:[{type:Schema.Types.ObjectId,ref:'user'}],
  teams: {type: Schema.Types.ObjectId, ref: 'team', required: true},
  permissions: {type: Schema.Types.Mixed},//ACL
  color: {type: String},
  //from logic
  role: {type: Number, required: true, default: 2},//Role constant - 2
  clientId: {type: String, required: true},
  isDeleted: {type: Number, default: 0},
  cognitoSub: {type: String, required: true},
  created_at: {type: Date, default: Date.now}
});

module.exports = mongoose.model('users', managerSchema);

