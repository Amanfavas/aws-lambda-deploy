const result = require('./result');
const settingModel = require('./model');
const helper = require('./util');


module.exports = {
  updateSetting: (event, cb, principals) => {
    const data = helper.getBodyData(event);
    if (!data) {
      result.invalidInput(cb);
    } else {
      const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
      settingModel.update({clientId: clientId}, {$set: {isCurrent: false}}, {multi: true})
        .then((res) => {
          console.log(res);
          return settingModel.update({businessType: data.businessType, clientId: clientId}, {$set: {isCurrent: true}});
        }).then((res) => {
        result.sendSuccess(cb, res);
      })  .catch((err) => {
        console.log('err++++ ', JSON.stringify(err));
        result.sendServerError(cb);
      });
    }
  }
};


// zip -r category_edit *
// category_edit.zip
