let cb;
const result = require('./result');
let aws = require('aws-sdk');
let multerS3 = require('multer-s3');
let multer = require('multer');

try {

  // const callback = function (err, data) {
  //   console.log('callback called+++++++++++++++++++++++++++++++++');
  //   console.log(err,data);
  // };
  // const event = require('../../mock').admin.event;
  // event.body = require('../../mock').data.createTeam;

  exports.handler = (event, context, callback) => {
    cb = callback;
    context.callbackWaitsForEmptyEventLoop = false;

    console.log(event);
    //imports
    const helper = require('./util');

    if (helper.checkFromTrigger(cb, event)) return;

    /*
    principals explanation: for admin sub is clientId for manager clientId is clientId
    {  sub: 'current user cognitosub',
    role: 'role id of user',
    clientId:'exist if user is manager & this is clientid of that manager',
    teams: 'team Assigned to manager' }
    */

    const principals = helper.getPrincipals(cb, event);
    if (!principals) return;

    //file upload

    aws.config.loadFromPath('./config.json');
    aws.config.update({signatureVersion: 'v4'});
    var s0 = new aws.S3({});
    var upload = multer({
      storage: multerS3({
        s3: s0,
        bucket: 'deliforce-fileupload',
        acl: 'public-read',

        metadata: function (event, file, cb1) {
          cb1(null, {fieldName: file.fieldname})
        },
        key: function (event, file, cb1) {
          cb1(null, Date.now() + file.originalname)
        }


      })
    }).any();

    upload(event.body, result, (error) => {

      if (error) {
        sendError(error)
      }
      else {
        result.sendSuccess(cb, data.files[0].location)
      }
    })

    function sendError(error) {
      console.error('error +++', error);
      result.sendServerError(cb);
    }
  };

} catch (err) {
  console.error('error +++', err);
  result.sendServerError(cb);
}
