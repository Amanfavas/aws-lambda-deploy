const common = require('./error').CODES;
const manager = require('./error').MANAGER_CODES;

module.exports = {

  sendServerError: (cb) => {
    cb(null, formResponse(common.SERVER_ERROR, {}));
  },

  sendSuccess: (cb, body) => {
    cb(null, formResponse(common.SUCCESS, body));
  },

  businessMissing: (cb) => {
    cb(null, formResponse(common.BUSINESS_TYPE_REQUIRED, {}));
  },

  sendResult: (statusCode, body, cb) => {
    cb(null, statusCode, body);
  },

  sendUnAuth: (cb) => {
    cb(null, formResponse(common.AUTH, ''));
  },

  fromTrigger: (cb) => {
    console.log('fromTrigger');
    cb(null, formResponse(400, ''));
  },

  invalidInput: (cb) => {
    cb(null, formResponse(common.BAD_REQUEST, ''));
  },

  //manager

  sendEmailInvalid: (cb) => {
    cb(null, formResponse(common.EMAIL_INVALID, ''));
  },

  sendPhoneInvalid: (cb) => {
    cb(null, formResponse(common.PHONE_INVALID, ''));
  },

  sendInvalidPhoneOrEmail: (cb) => {
    cb(null, formResponse(manager.INVALID_PHONE_OR_EMAIL), '');
  },

  sendPasswordInvalid: (cb) => {
    cb(null, formResponse(common.PASSWORD_INVALID, ''));
  },

  sendTeamMandatory: (cb) => {
    cb(null, formResponse(manager.TEAM_MANDATORY, ''));
  },

  sendDuplicateEmail: (cb) => {
    cb(null, formResponse(manager.DUPLICTE_EMAIL, ''));
  },

  sendDuplicatePhone: (cb) => {
    cb(null, formResponse(manager.DUPLICATE_PHONE, ''));
  }

};

function formResponse(code, body) {
  const response = {headers: {'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'}};
  const result = (typeof body === 'object') ? JSON.stringify(body) : body;
  return Object.assign(response, {statusCode: code, body: result});
}
