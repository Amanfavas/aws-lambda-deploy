const constant = require('./constant');
const managerModel = require('./model').manager;
const cognito = require('./cognito');
const result = require('./result');
const helper = require('./util');
const permission = require('./permission');

module.exports = {
  createManager: checkDuplicate
};


function checkDuplicate(cb, event, clientId) {
  const data = helper.getBodyData(event);
  if (!data) {
    result.invalidInput(cb);
    return
  }

  //addManager(data, cb, clientId);
  managerModel.findOne({"$or": [{email: data.email}, {phone: data.phone}]}, (err, manager) => {
    if (err) {
      result.sendServerError(cb)
    } else if (manager) {
      sendDuplicate(manager);
    } else {
      validateManagerData(data, cb, clientId);

    }
  });


  function sendDuplicate(manager) {
    if (manager.email === data.email) {
      result.sendDuplicateEmail(cb);
    } else {
      result.sendDuplicatePhone(cb);
    }
  }
}


//before create cognito user do validate
function validateManagerData(data, cb, clientId) {

  if(!data.teams || !data.teams.length){
    result.sendTeamMandatory(cb);
  }

  const testData = Object.assign({}, data, {clientId: clientId, cognitoSub: '23232332'});
  const adminData = new managerModel(testData);

  adminData.validate((err) => {
    if (err) {
      managerError(err, cb);
    } else {
      cognitoManager(data, cb, clientId);
    }
  })
}

function cognitoManager(data, cb, clientId) {
  cognito.createUser(data).then((cognitoUser) => {
    if (!cognitoUser.userSub) {
      return new Error('user not created');
    } else {
      addManager(clientId, data, cognitoUser.userSub, cb);
    }
  }).catch((err) => sendCognitoError(err, cb));
}

function addManager(clientId, data, cognitoSub, cb) {
  const mangerData = Object.assign({}, data, {
    clientId: clientId,
    cognitoSub: cognitoSub
  });

  const manager = new managerModel(mangerData);
  manager.save().then((manager) => {
    setPermission(data, cognitoSub, manager, cb);
  }).catch((err) => managerError(err, cb));
}


function managerError(err, cb) {
  const errors = err.errors;
  if (errors && errors.teams) {
    result.sendTeamMandatory(cb)
  } else {
    result.sendServerError(cb);
  }
}

function setPermission(data, cognitoSub, manager, cb) {
  permission.setPermission(data.permissions, cognitoSub)
    .then(() => {
      result.sendSuccess(cb, manager);
    })
    .catch((err) => {
      console.log('permission not setted', err);
      result.sendSuccess(cb, manager);
    })
}


function sendCognitoError(err, cb) {
  console.log('cognito error', err);
  const cognito = constant.COGNITO_ERROR;
  if (err.code === cognito.PASSWORD_INVALID) {
    result.sendPasswordInvalid(cb);
  } else if (err.code === cognito.EMAIL_EXIST) {
    result.sendDuplicateEmail(cb);
  } else if (err.code === cognito.INVALID_DATA) {
    console.log('invalid phone or email');
    result.sendInvalidPhoneOrEmail(cb);
  } else {
    result.sendServerError(cb);
  }
}
