module.exports = {
  "TASK_STATUS": {
    "UNASSIGNED": 1,
    "ASSIGNED": 2,
    "ACCEPTED": 3,
    "STARTED": 4,
    "INPROGRESS": 5,
    "SUCCESS": 6,
    "FAIL": 7,
    "DECLINED": 8,
    "CANCELLED": 9
  },

  "DRIVER_STATUS": {
    "IDLE": 1,
    "IN_TRANSIT": 2,
    "OFFLINE": 3,
    "BLOCKED": 4,
    "FIRST_LOGIN": 0
  },

  "TEAM_ACCURACY": {
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "NO_TRACKING": 4
  },

  "TASK_LOG_STATUS": {
    "CREATED": 0,
    "UNASSIGNED": 1,
    "ASSIGNED": 2,
    "ACCEPTED": 3,
    "STARTED": 4,
    "INPROGRESS": 5,
    "SUCCESS": 6,
    "FAIL": 7,
    "DECLINED": 8,
    "CANCELLED": 9,
    "UPDATED": 10,
    "DELETED": 11
  },

  //common

  "TABLES": {
    "DRIVER": "users",
    "MANAGER": "users",
    "ADMIN": "users",
    "TEAM": "teams",
    "TASK": "tasks",
    "SETTING": "settings",
    "TASK_LOG": "tasklogs",
    "PERMISSION": "permissions",
    "CUSTOMER": "customers",
    "PREFERENCE": "preferences",
    "DRIVERLOG": "driverlogs",
    "USER": "users"
  },

  "DB": {
    "URL": "mongodb://vignesh:Vignesh123@deliforce-shard-00-00-6geto.mongodb.net:27017," +
    "deliforce-shard-00-01-6geto.mongodb.net:27017," +
    "deliforce-shard-00-02-6geto.mongodb.net:27017/deliforce?replicaSet=deliforce-shard-0&authSource=admin&ssl=true",
    "POOL_SIZE": 2
  },

  "ROLE": {
    "ADMIN": 1,
    "MANAGER": 2,
    "DRIVER": 3
  },


  "isIt": {
    "YES": 1,
    "NO": 0
  },

  "BUSINESS_TYPE": {
    "PICKUP": 1,
    "APPOINTMENT": 2,
    "FIELD": 3
  },

  "STATUS": {
    "DUPLICATE_MANAGER_EMAIL_AND_PHONENUMBER": 208,
    "REQUIRED_EMAIL": 212,
    "REQUIRED_NAME": 213,
    "REQUIRED_PHONE": 214,
    "REQUIRED_PASSWORD": 215
  },
  "AUTHORIZE": {
    "ALLOW": 1,
    "DENY": 0
  },

  "PRINCIPAL": {
    "ROLE": 1,
    "USER": 2
  },

  "AWS": {
    "region": "ap-south-1",
    "identityPoolId": "",
    "userPoolId": "ap-south-1_8FgFULsTo",
    "clientId": "7be5tjeatbifqk4d1arqi90m45",
    "cognito_idp_endpoint": "",
    "cognito_identity_endpoint": "",
    "sts_endpoint": "",
    "dynamodb_endpoint": "",
    "s3_endpoint": ""
  },

  "COGNITO_ERROR": {
    "INVALID_DATA": 'InvalidParameterException',
    "EMAIL_EXIST": 'UsernameExistsException',
    "PASSWORD_INVALID": 'InvalidPasswordException'
  }
};

//{"fromTrigger":1}
