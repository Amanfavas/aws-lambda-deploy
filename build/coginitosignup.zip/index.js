let cb;
const result = require('./result');

try {
  const getConstant = require('./constant')();
  /*
	const callback = function (err, data) {
		console.log(err,data);
	  };

	  const event = require('./mock').event;
  */

  exports.handler = (event, context, callback) => {

    console.log(JSON.stringify(event));

    cb = callback;
    context.callbackWaitsForEmptyEventLoop = false;

    getConstant.then(() => {
      //imports
      const admin = require('./admin');
      const helper = require('./util');
      //for trigger
      if (helper.checkFromTrigger(cb, event)) return;
      //init
      admin.signupUser(event, cb);
    }).catch((err) => {
      console.log(err);
      result.sendServerError(cb)
    });


  };

} catch (err) {
  console.log(err);
  result.sendServerError(cb);
}
