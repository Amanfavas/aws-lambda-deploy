module.exports = {

  settings: [
    {
      "businessType": 1,
      "isCurrent": true,

      "actionBlock": {
        "notes": {
          "exist": true,
          "isMandatory": false
        },

        "image": {"exist": false, "isMandatory": false},
        "signature": {"exist": false, "isMandatory": false},
        "barcode": {"exist": false, "isMandatory": false},
        "imageCaption": {"exist": false, "isMandatory": false}
      },

      "acknowledgementType": 1,
      "notifications": {
        "Received": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Started": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Arrived": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Sucess": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Failed": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''}
      },

      "autoAllocation": {

        "nearest": {
          "radius": 16,
          "current": false,
          "expiry": 30,
          "retries": 10
        },

        "sendToAll": {
          "current": false,
          "expiry": 30,
          "retries": 10
        },
        "oneByOne": {
          "current": true,
          "expiry": 30,
          "retries": 10
        }
      }
    },
    {
      "businessType": 2,
      "isCurrent": false,

      "actionBlock": {
        "notes": {
          "exist": true,
          "isMandatory": false
        },

        "image": {"exist": false, "isMandatory": false},
        "signature": {"exist": false, "isMandatory": false},
        "barcode": {"exist": false, "isMandatory": false},
        "imageCaption": {"exist": false, "isMandatory": false}
      },

      "acknowledgementType": 1,
      "notifications": {

        "Received": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Started": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Arrived": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Sucess": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Failed": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''}
      },


      "autoAllocation": {

        "nearest": {
          "radius": 16,
          "current": false,
          "expiry": 30,
          "retries": 10
        },

        "sendToAll": {
          "current": false,
          "expiry": 30,
          "retries": 10
        },
        "oneByOne": {
          "expiry": 30,
          "current": true,
          "retries": 10
        }
      }
    },
    {
      "businessType": 3,
      "isCurrent": false,

      "actionBlock": {
        "notes": {
          "exist": true,
          "isMandatory": false
        },

        "image": {"exist": false, "isMandatory": false},
        "signature": {"exist": false, "isMandatory": false},
        "barcode": {"exist": false, "isMandatory": false},
        "imageCaption": {"exist": false, "isMandatory": false}
      },
      "acknowledgementType": 1,
      "notifications": {

        "Received": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Started": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Arrived": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Sucess": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''},
        "Failed": {"web": true, "sms": true, "email": false, smsTemp: '', mailTemp: ''}
      },

      "autoAllocation": {

        "nearest": {
          "radius": 16,
          "current": false,
          "expiry": 30,
          "retries": 10
        },

        "sendToAll": {
          "current": false,
          "expiry": 30,
          "retries": 10
        },
        "oneByOne": {
          "expiry": 30,
          "current": true,
          "retries": 10
        }
      }

    }],
  preference: {
    'customizeAgentTextAs': 'Driver',
    'customizeManagerTextAs': 'Manager',
    'dashboardLanguage': {'text': 'English', 'id': 'en'},
    'customerTrackingLanguage': {'text': 'English', 'id': 'en'},
    'timeZone': {
      // 'text': 'India Standard Time',
      'abbr': 'IST',
      'offset': 5.5,
      'isdst': false,
      'text': '(UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi',
      ' utc': ['Asia/Kolkata']

    },
    'distance': {'text': 'Kilometer', 'id': 1}

  }

};
