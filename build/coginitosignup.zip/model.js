const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant')();
const role = constant.ROLE;
const isIt = constant.isIt;


const settingSchema = new Schema({
  businessType: {type: Number, required: true},
  isCurrent: {type: Boolean, required: true},
  autoAllocation: Schema.Types.Mixed,
  notifications: Schema.Types.Mixed,
  actionBlock: Schema.Types.Mixed,
  acknowledgementType: Schema.Types.Mixed,
  clientId: {type: String, required: true},
});

const preferenceSchema = new Schema({
  customizeAgentTextAs: Schema.Types.Mixed,
  customizeManagerTextAs: Schema.Types.Mixed,
  dashboardLanguage: Schema.Types.Mixed,
  customerTrackingLangauge: Schema.Types.Mixed,
  distance: Schema.Types.Mixed,
  timeZone: Schema.Types.Mixed,
  clientId: {type: String, required: true},
});

const adminSchema = new Schema({
  name: {type: String, required: true},
  email: {type: String, required: true},//cognito validation
  phone: {type: String, required: true},//cognito validation(+91 32323)
  password: {type: String, required: true},//cognito min 8 char ,alpha(upper,lower) numeric, special character
  role: {type: Number, required: true, default: role.ADMIN},//Role constant - 1
  cognitoSub: {type: String, required: true},
  isDeleted: {type: Number, default: isIt.NO},
  companyName: {type: String},
  companyAddress: {type: String},
  country: {type: String},
  image: {type: String},
  created_at: {type: Date, default: Date.now}
});




const settingModel = mongoose.model('setting', settingSchema);
const preferenceModel = mongoose.model('preference', preferenceSchema);
const adminModel = mongoose.model('user', adminSchema);

module.exports = {setting: settingModel, preference: preferenceModel, admin: adminModel};






