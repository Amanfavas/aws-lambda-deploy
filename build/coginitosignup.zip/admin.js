const cognito = require('./cognito.js');
const defaults = require('./default');
const constant = require('./constant')();
const settingModel = require('./model').setting;
const preferenceModel = require('./model').preference;
const adminModel = require('./model').admin;
const db = require('./db').connect();
const util = require('./util');
const result = require('./result');

module.exports = {
  signupUser: signupUser
};


function sendError(error, cb) {
  console.error('error +++', error);
  result.sendServerError(cb);
}

function signupUser(event, cb) {
  db.then(() => {
    const data = util.getBodyData(event);
    if (!data) {
      result.invalidInput(cb);
      return
    } else {
      createCognitoUser(data, cb);
    }
  }).catch((err) => {
    console.log('error on db connection');
    sendError(err, cb);
  })
}

function createCognitoUser(data, cb) {
  cognito.createUser(data)
    .then((cognitoUser) => {
      const cognitoSub = cognitoUser.userSub;
      if (!cognitoSub) {
        console.log('sub not found on cognito');
        result.sendServerError(cb);
      }
      doNeed(cognitoSub, data, cb);
    }).catch((err) => sendCognitoError(err, cb));
}


function sendCognitoError(err, cb) {
  console.log('cognito error', err);
  const cognito = constant.COGNITO_ERROR;
  if (err.code === cognito.PASSWORD_INVALID) {
    result.sendPasswordInvalid(cb)
  } else if (err.code === cognito.EMAIL_EXIST) {
    result.sendDuplicateEmail(cb);
  } else if (err.code === cognito.INVALID_DATA) {
    console.log('invalid phone or email');
    result.sendInvalidPhoneOrEmail(cb);
  } else {
    result.sendServerError(cb);
  }
}


/*
const data = ;
*/

// create defaults
function doNeed(cognitoSub, data, cb) {
  createAdmin(cognitoSub, data)
    .then((admin) => {
      console.log('admin created');
      return createDefaults(admin);
    }).then(() => {
    result.sendSuccess(cb, {});
  }).catch((err) => {
    sendError(err, cb);
  });
}

function createAdmin(cognitoSub, data) {
  const adminData = Object.assign(data, {cognitoSub: cognitoSub, role: constant.ROLE.ADMIN});
  return new adminModel(adminData).save();
}

function createDefaults(admin) {
  const clientId = admin['cognitoSub'];
  const promises = [];
  const extend = {clientId: clientId};
  //create settings
  const settings = defaults.settings.map((s) => Object.assign(s, extend));
  promises.push(settingModel.insertMany(settings));
  //create preference
  const preference = new preferenceModel(Object.assign(defaults.preference, extend));
  promises.push(preference.save());
  return Promise.all(promises);
}
