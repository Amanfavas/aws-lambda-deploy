const common = require('./error').CODES;
const driver = require('./error').DRIVER_CODES;


module.exports = {

  sendServerError: (cb) => {
    cb(null, formResponse(common.SERVER_ERROR, {}));
  },

  sendSuccess: (cb, body) => {
    cb(null, formResponse(common.SUCCESS, body));
  },

  businessMissing: (cb) => {
    cb(null, formResponse(common.BUSINESS_TYPE_REQUIRED, {}));
  },

  CagnitoSub: (cb) => {
    cb(null, formResponse(common.BUSINESS_TYPE_REQUIRED, {}));
  }
  ,
  sendResult: (statusCode, body, cb) => {
    cb(null, statusCode, body);
  },

  sendUnAuth: (cb) => {
    cb(null, formResponse(common.AUTH, {message: 'Unauthorized'}));
  },

  fromTrigger: (cb) => {
    console.log('fromTrigger');
    cb(null, formResponse(400, ''));
  },

  invalidInput: (cb) => {
    cb(null, formResponse(common.BAD_REQUEST, ''));
  },


  //app

  invalidEmail: (cb) => {
    cb(null, formResponse(common.EMAIL_INVALID, {message: 'invalid Email'}));
  },

  invalidName: (cb) => {
    cb(null, formResponse(common.NAME_INVALID, {message: 'invalid Name'}));
  },
  invalidPassword: (cb) => {
    cb(null, formResponse(common.PASSWORD_INVALID, {message: 'invalid Password'}));
  },
  invalidPhone: (cb) => {
    cb(null, formResponse(common.PHONE_INVALID, {message: 'invalid Phone'}));
  },


  TeamMandatory: (cb) => {
    cb(null, formResponse(driver.TEAM_MANDATORY, {message: 'Team is Mandatory'}));
  },

  Duplication: (cb) => {
    cb(null, formResponse(driver.DUPLICATE_DRIVER_NAME_AND_EMAIL, {message: 'Duplication of Driver and Email'}));
  }


};

function formResponse(code, body) {
  const response = {headers: {'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*'}};
  const result = (typeof body === 'object') ? JSON.stringify(body) : body;
  return Object.assign(response, {statusCode: code, body: result});
}
