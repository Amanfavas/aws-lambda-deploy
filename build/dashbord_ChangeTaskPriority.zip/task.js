const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const constant = require('./constant')();
const model = require('./model');



module.exports = {

  upsertTask:(event, cb, principals) => {
    console.log(event);
    const data = helper.getBodyData(event);
    console.log(data);

    if (!data) {
      result.invalidInput(cb);
    }
    else {
      const taskModel = model.task.getTaskModel(data['businessType']);
      console.log(taskModel);
      if (!taskModel) {
        return Promise.reject();
      }
      console.log(data.businessType);
      const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
      var bulk = taskModel.collection.initializeUnorderedBulkOp();
      for (var i = 0; i < data.taskArry.length; i++) {
        console.log('for loop');
        bulk.find({
          _id: mongoose.Types.ObjectId(data.taskArry[i]._id),
          'clientId': clientId
        }).update({$set: {priority: data.taskArry[i].priority}});
        // taskModel.update({_id:data.data[i]._id},{$set:{priority:data.data[i].priority}})

      }

      bulk.execute(function (error, data) {
        console.log('bulk');
        if (error) {
          console.log(error);
          result.sendServerError(cb);
        }
        else {
          result.sendSuccess(cb, data);

        }

      });
    }
  }


};



//princial  manager- clientId , role , sub , teams
//admin - sub , role




