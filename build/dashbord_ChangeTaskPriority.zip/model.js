const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant');
const tables = constant.TABLES;
const business = constant.BUSINESS_TYPE;

const validator = require('./validator');
const role = constant.ROLE;
const roleEnum = [role.ADMIN, role.DRIVER, role.MANAGER];
const isIt = constant.isIt;

//pickup & delivery or same schema
const taskPickupSchema = new Schema({
  name: {type: String, required: true},//customer name
  phone: {type: String, required: true, validate: validator.phoneValidateEmpty},//validation with countrycode
  email: {type: String, validate: validator.emailValidator},
  address: {type: Schema.Types.Mixed, required: true},
  date: {type: Date, required: true}, //pickup before data (or) delivery before
  description: {type: String},
  driver: {type: Schema.Types.ObjectId, ref: 'user'},
  team: {type: Schema.Types.ObjectId, ref: 'team'},
  transportType: {type: Number},
  orderId: {type: String},
  images: Schema.Types.Mixed,
  priority: {type: Number, default: isIt.NO},//drag and drop functionality
  completedDate: {type: Date},
  //from logic
  taskStatus: {type: Number, required: true}, //Task Status
  clientId: {type: String, required: true},
  isDeleted: {type: Number, default: isIt.NO},
  created_at: {type: Date, default: Date.now},
  businessType: {type: Number, required: true},
  settings: {type: Schema.Types.Mixed, required: true},
  delay: {type: Number, default: isIt.NO, required: true}
});


const taskAppointmentSchema = new Schema({
  name: {type: String, required: true},//customer name
  phone: {type: String, required: true, validate: validator.phoneValidateEmpty},//validation with countrycode
  email: {type: String, validate: validator.emailValidator},
  address: {type: Schema.Types.Mixed, required: true},
  date: {type: Date, required: true}, //startDate
  endDate: {type: Date, required: true},
  description: {type: String},
  driver: {type: Schema.Types.ObjectId, ref: 'user'},
  team: {type: Schema.Types.ObjectId, ref: 'team'},
  transportType: {type: Number},
  orderId: {type: String},
  images: Schema.Types.Mixed,
  priority: {type: Number, default: isIt.NO},//drag and drop functionality
  completedDate: {type: Date},
  //from logic
  taskStatus: {type: Number, required: true}, //Task Status
  clientId: {type: String, required: true},
  isDeleted: {type: Number, default: isIt.NO},
  created_at: {type: Date, default: Date.now},
  businessType: {type: Number, required: true},
  settings: {type: Schema.Types.Mixed, required: true},
  delay: {type: Number, default: isIt.NO, required: true}
});


const taskWorkForceSchema = new Schema({
  name: {type: String, required: true},//customer name
  phone: {type: String, required: true, validate: validator.phoneValidateEmpty},//validation with countrycode
  email: {type: String, validate: validator.emailValidator},
  address: {type: Schema.Types.Mixed, required: true},
  date: {type: Date, required: true}, //start date
  endDate: {type: Date, required: true},
  description: {type: String},
  driver: {type: Schema.Types.ObjectId, ref: 'user'},
  team: {type: Schema.Types.ObjectId, ref: 'team'},
  transportType: {type: Number},
  orderId: {type: String},
  images: Schema.Types.Mixed,
  priority: {type: Number, default: isIt.NO},//drag and drop functionality
  completedDate: {type: Date},
  //from logic
  taskStatus: {type: Number, required: true}, //Task Status
  clientId: {type: String, required: true},
  isDeleted: {type: Number, default: isIt.NO},
  created_at: {type: Date, default: Date.now},
  businessType: {type: Number, required: true},
  settings: {type: Schema.Types.Mixed, required: true},
  delay: {type: Number, default: isIt.NO, required: true}
});




function getTaskModel(businessType) {
  let taskModel;
  if (businessType === business.APPOINTMENT) {
    taskModel = mongoose.model(tables.TASK, taskAppointmentSchema);
  } else if (businessType === business.FIELD) {
    taskModel = mongoose.model(tables.TASK, taskWorkForceSchema);
  } else {
    taskModel = mongoose.model(tables.TASK, taskPickupSchema);
  }
  return taskModel;
}

module.exports = {
  task: {getTaskModel: getTaskModel}

};
