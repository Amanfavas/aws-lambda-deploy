
let cb;
let aws = require('aws-sdk');
let multerS3 = require('multer-s3');
let multer = require('multer');
let express = require('express');

const bodyParser = require('body-parser');
const cors = require('cors');
const compression = require('compression');
const helper =require('./util');


//aws middleware
const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware');
let mongoose = require('mongoose');
let app = express();
const db = require('./db').connect();
const result = require('./result');
const errorCode =require('./error').CODES;
const model= require('./model');
const fs = require('fs');
const csv = require("fast-csv");
const taskS = require('./constant').TASK_STATUS;
const businessT= require('./constant').BUSINESS_TYPE;
const CUSTOMER  = require('./model').customerModel;
const settingsModel= require('./model').settingModel


app.use(compression())
app.use(cors())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(awsServerlessExpressMiddleware.eventContext())





function DateChecker(date) {
  return !(new Date(date) == 'Invalid Date');
}
function ValidateEmail(mail)
{
  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
  {
    return (true)
  }

  return (false)
};

function phoneValidation(d) {
  const regex = /^\d+$/;
  const split = d.substring(1).split(' ');
  if (d.charAt(0) !== '+') {
    return false
  } else if (split.length === 2) {
    var arr = split.filter((s) => !regex.test(s));
    return (!arr.length)
  } else {
    return false;
  }
};
function getSettings(id){
  console.log('SCId'+id)
  settingsModel.findOne({clientId:id,isCurrent:true},function(error,data){
    if(error){
      console.log('setting error')
      return false
    }
    else{
      console.log(data);
      return data;
    }
  })
}

aws.config.loadFromPath('./config.json');
aws.config.update({signatureVersion:'v4'});
let s3= new aws.S3({});
let upload=multer({
  storage:multerS3({
    s3:s3,
    bucket:'deliforce-fileupload',
    acl:'public-read',

    metadata:function(req,file,cb){
      cb(null,{fieldName:file.fieldname});
    },
    fileFilter: function (req, file, cb) {
      if (!file.originalname.match(/\.(csv)$/)) {
        return cb(new Error('Only image files are allowed!'));
      }
      cb(null, true);
    },
    key:function(req,file,cb){

      cb(null, Date.now() + file.originalname);
    }


  })
});

// upload.any()
app.post('/task/import',upload.single('image'),function(req,res,next) {
  console.log(JSON.stringify(req.apiGateway.event));
  const principals = helper.getPrincipals(cb,req.apiGateway.event);
  if (!principals) return;
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  console.log(req.file);
  const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
   const settings=getSettings(clientId)
  if(!settings){
     console.log('settings is not exist')
    res.send('server side problem(settings missing)')
  };
  const businessType=settings.businessType;
  const taskModel = model.task.getTaskModel(businessType);
  if (!taskModel) {
    return res.send(errorCode.BUSINESS_TYPE_REQUIRED);
  }

  var path = req.file.key;
  aws.config.loadFromPath('./config.json');
  aws.config.update({signatureVersion:'v4'});
  respon=[];

  const s1 = new aws.S3();
  const stream = s1.getObject({ Bucket: 'deliforce-fileupload', Key: path }).createReadStream();

  var parser = csv.fromStream(stream, { headers: true })
    .on("data", function (data) {
      //console.log(data);
      respon.push(data);

    }).on("end", function (data) {
      // console.log(respon);
      //console.log(respon.length);
      var sucessCount=0;
      var failureCount=0;
      var dataArry=[];


      for ( var i=0;i<respon.length;i++ ) {

        if (respon[i].name && respon[i].phone && phoneValidation(respon[i].phone) &&respon[i].date  && DateChecker(respon[i].date) && respon[i].address )
        {
          //todo actual settings we need to store
          var query={'name':respon[i].name,'phone':respon[i].phone,clientId:clientId,
            'address':respon[i].address, 'businessType':businessType,'date':respon[i].date,'settings':settings };
          query.taskStatus=  (respon[i].agent)?taskS.ASSIGNED :taskS.UNASSIGNED;
          console.log(query);
          if(respon[i].email){
            query.email=ValidateEmail(respon[i].email)?respon[i].email:respon[i].email+'@domin.com';
          }
          if(businessType === businessT.FIELD || businessType === businessT.APPOINTMENT ){
            //console.log('bs2'+respon[i].name);

            if(respon[i].endDate && DateChecker(respon[i].endDate)&& respon[i].endDate >= respon[i].date){
              query.endDate=respon[i].endDate;
              dataArry.push(query);
              sucessCount++;
            }
            else{
              console.log('failurCount');
              failureCount++;
            }
          }
          else if(businessType ===businessT.PICKUP ||businessType ===businessT.DELIVERY){

             console.log('query is pushed')
            dataArry.push(query);
            sucessCount++;
          }


        } else{
          console.log('data missing');
          failureCount++

        }

      }
      console.log(sucessCount);
      console.log(failureCount);
      console.log(dataArry);
      if(dataArry.length){


        taskModel.insertMany(dataArry,function(error,data){
          if(error){
            console.log(error);
            res.send('server side errro')
          }
          else{
            console.log('customer')

            CUSTOMER.insertMany(dataArry,function(error){

              if(error){
                res.send('server side error'+error);
              }
              res.json({'sucessCount':sucessCount,'faieldCount':failureCount});
            })


          }
        })

      }
      else{
        res.send('sucess')
      }


    })

});
db.then(()=>{console.log('data base connectionestablished')

  let server = app.listen(8081, function () {
    let host = server.address().address;
    let port = server.address().port;
    console.log("Example app listening at http://%s:%s", host, port);
  });


})
  .catch((error)=>{process.exit(1)});



module.exports = app;
