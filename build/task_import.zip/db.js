const mongoose = require('mongoose');
//const constant = require('./constant')();
const DB={  "URL": "mongodb://Next!brain:Next!345%23@106.51.73.130:27017/deliforce?authSource=admin",
  "POOL_SIZE": 2};

module.exports = {
  connect: () => {
    console.log('connection state++ ', mongoose.connection.readyState);
    if (mongoose.connection && mongoose.connection.readyState === 1) {
      console.log('connection reused');
      return Promise.resolve();
    } else {
      console.log('connection created once again');
      return mongoose.connect(DB.URL, DB.OPTION);
    }
  }
};
